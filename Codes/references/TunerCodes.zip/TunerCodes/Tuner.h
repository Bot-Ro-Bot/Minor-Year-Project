#ifndef TUNER_H_
#define TUNER_H_

#include <Arduino.h>
#include <avr/io.h>
//#include "Tuner.cpp"

#define SCL PC5
#define SDA PC4

extern word low_band_max;         
extern word mid_band_max;       
extern word high_band_max; 


#define synthesizer_resolution 0.0625   // 4MHz/64 ->PLL: 8 x 7.8125KHz = 62.5KHz  

#define RX_IF (10.70+27.0)     // IF-frequency #1 = IF-frequency #2 + Quarz-frequency [MHz]
#define PopularRadio 105.600      // Receiving frequency Radio Zürichsee on CableCOM [MHz]



class Tuner
{
  public:
    void scanDevice();

    void i2c_sda(byte arg);
    void i2c_scl(byte arg);

    void i2c_init(void);
    void i2c_start(void);
    void i2c_stop(void);

    void i2c_write(byte);
    void i2c_read();
    void i2c_reader();

    void setTuner(float actualfrequency);

};


#endif
