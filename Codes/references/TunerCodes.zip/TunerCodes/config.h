#ifndef CONFIG_H_
#define CONFIG_H_


word low_band_max = 171;         
word mid_band_max = 450;       
word high_band_max = 863; 


#endif
