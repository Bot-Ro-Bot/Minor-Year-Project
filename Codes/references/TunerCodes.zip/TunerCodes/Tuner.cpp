#ifndef TUNER_CPP_
#define TUNER_CPP_

#include <Arduino.h>
//#include <PinChangeInt.h>

#include <Wire.h>
#include "Tuner.h"


 uint8_t reading = 0;
volatile uint8_t sdata=0;

void Tuner::scanDevice()
{
  int devices = 0, error = 0;
  for(int address = 1; address < 127; address++ ) 
  {
    Wire.beginTransmission(address);
    error = Wire.endTransmission();
    if (error == 0)
    {
      Serial.print("I2C device found at address | 0x");
      if (address<16) 
        Serial.print("0");
      Serial.print(address,HEX);
      Serial.println("  !");
      devices++;
    }
    else if (error==4) 
    {
      Serial.print("Unknow error at address | 0x");
      if (address<16) 
        Serial.print("0");
      Serial.println(address,HEX);
    }    
  }
  if (devices == 0)
    Serial.println("No I2C devices found\n");
  else
    Serial.println("done\n");
}
void Tuner::i2c_init(void)
{
  i2c_scl(1);
  i2c_sda(1);
}
void Tuner::i2c_sda(byte arg)
{
  PORTC = (PORTC & (~(1<< SDA)))|(arg << SDA);
}
void Tuner::i2c_scl(byte arg)
{
  PORTC = (PORTC & (~(1<< SCL)))|(arg << SCL);
}
void Tuner::i2c_start(void)
{
  i2c_sda(0);
  i2c_scl(0);
  i2c_sda(1);
  i2c_scl(1);
  i2c_sda(0);
  i2c_scl(0);
}
void Tuner::i2c_stop(void)
{
  i2c_sda(0);
  i2c_scl(0);
  i2c_sda(1);
  i2c_scl(1);
}
void Tuner::i2c_write(byte arg)
{
  byte power = 128;
  for(byte i =0;i<8;i++)
  {
    i2c_sda(0);
    i2c_scl(0);
    if((arg & power)==power)
    {
      i2c_sda(1);
      i2c_scl(1);
      i2c_scl(0);
      i2c_sda(0);
    }
    else
    {
      i2c_sda(1);
      i2c_scl(1);
      i2c_scl(0);
    }
    power = power/2;
  }
  //get ack
  i2c_scl(1);
  i2c_scl(0);
}

void Tuner::i2c_reader()
{
  unsigned char z = 0x00,q=0x80,flag=0;
  i2c_sda(1);
  for(int i=0;i<8;i++)
  {
    i2c_scl(1);
//    delay(100);
    if(PINC & (1<<SDA))
    {
      z = (z|q);
      q=q>>1;
//      delay(100);
      i2c_scl(0);
    }
  }
  Serial.print("value = "),Serial.println(z);
}


void Tuner::i2c_read()
{
  /*interrupt enable for pcint 8 to 14 contains scl and sda at 
   *pcint 13 and 12 respectively
   */
  PCICR  |= (1<<PCIE1); 
  PCMSK1 |= (1<<PCINT13);
  //to act on the change in data
  PCIFR  &= ~(1<<PCIF1);

  int c=0;
  i2c_start();
  while(reading != 1)
  {
    c = (c<10)?Serial.print("."),c+1:Serial.println(c),0;
      delay(50);
  }
  reading = 0;
    PCICR  &= ~(1<<PCIE1);
  PCMSK1 &= ~(1<<PCINT13);
}

ISR(PCINT1_vect)
{
  static byte count;
  byte currentState = PINC;
  byte dataClock = currentState & (1<<PC5);
  byte dataData;
  if(dataClock)
  {
    dataData = currentState & (1<<PC4);
    if(count < 8 )
    {
      if(dataData)
        sdata |= (1<< count);
      else
        sdata &= ~(1<< count);
      count++;
      if(count==8)
        reading = 1,Serial.print("read value"),Serial.println(sdata);
    }
    else
      count = 0,sdata=0; 
  }
}


void Tuner::setTuner(float actualfrequency)
{
  word divider;
  byte db1,db2;
  byte adb,cb,bb;
  byte if_init = 0;

  adb = 128 + 64 + 0;     // evaluate tuner adress byte 110000xxB
    
    // estimate oscillator divider bytes
    divider=(unsigned int)( (actualfrequency+if_init)/synthesizer_resolution); // MHz->KHz->channel
    db1 = (byte) (divider / 256);   // evaluate first data byte
    db2 = (byte) (divider % 256);   // evaluate second data byte

    cb = 128 + 64 + 4 + 2;    // tuner control byte 62.5khz
 
    // bb setting according to oscillator frequency (band select)
    if (actualfrequency <= low_band_max)  // low band 51-171MHz = 00000001
        bb = 1; 
    else
    {
        if (actualfrequency <= mid_band_max) // mid band 178-450MHz = 00000010
            bb = 2; 
        else        // high band 458-858MHz = 00000100
            bb = 4; 
    }            
                  
    // Output sequence to device via digital-I/O-Port, send start bit first
    i2c_start();
    
    i2c_write(adb); // Send address byte
    i2c_write(db1); // Send divider byte 1
    i2c_write(db2); // Send divider byte 2
    i2c_write(cb);  // Send control byte
    i2c_write(bb);  // Send band-switch byte
    
    // Send stopp bit
    i2c_stop();
}


#endif


