package com.uzzors2k.tvtunerpanel;

import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.UUID;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private SeekBar frequencyBar;
	private Button updateTunerButton;
	private TextView dividerText;
	private TextView frequencyText;
	private TextView bandText;
	private RadioGroup bandRadioGroup;
	private TextView lowerLimitText;
	private TextView upperLimitText;
	private Button dividerDecButton;
	private Button dividerIncButton;
	
	private int lastProgressBarValue;
	
	private byte selectedBand;
	private int dividerRatio;
	//private byte dividerLSB;
	
	static final private double IF_FREQUENCY = 38.2;
	static final private double RANGE_START = 48.25;
	static final private double RANGE_MID = 170.00;
	static final private double RANGE_HI = 450.00;
	static final private double RANGE_END = 855.25;
	
	// Bluetooth stuff
	ProgressDialog myProgressDialog;
    private Toast failToast;
    private Handler mHandler;
	// Intent request codes
    private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    // More BT stuff
    private BluetoothAdapter mBluetoothAdapter = null;
    private BluetoothSocket btSocket = null; 
    private OutputStream outStream = null;
    private ConnectThread mConnectThread = null;
    private String deviceAddress = null;
    // Well known SPP UUID (will *probably* map to RFCOMM channel 1 (default) if not in use); 
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// Get handles to objects
		frequencyBar = (SeekBar) findViewById(R.id.frequencyBar);
		updateTunerButton = (Button) findViewById(R.id.updateButton);
		dividerText = (TextView) findViewById(R.id.dividerTextbox);
		frequencyText = (TextView) findViewById(R.id.frequencyTextBox);
		bandText = (TextView) findViewById(R.id.bandValueTextBox);
		bandRadioGroup = (RadioGroup) findViewById(R.id.radioGroup1);
		lowerLimitText = (TextView) findViewById(R.id.lowerLimitText);
		upperLimitText = (TextView) findViewById(R.id.upperLimitTExt);
		dividerDecButton = (Button) findViewById(R.id.dividerDecButton);
		dividerIncButton = (Button) findViewById(R.id.dividerIncButton);
		
		// Defaults, set so they correspond to values shown
		lastProgressBarValue = 0;
		selectedBand = 5;
		updateState(0);
		
		// Check whether bluetooth adapter exists
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter(); 
        if (mBluetoothAdapter == null) { 
             Toast.makeText(this, R.string.no_bt_device, Toast.LENGTH_LONG).show(); 
             finish(); 
             return; 
        } 
        
        // If BT is not on, request that it be enabled.
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        }
		
        myProgressDialog = new ProgressDialog(this);
        failToast = Toast.makeText(this, R.string.failedToConnect, Toast.LENGTH_SHORT);
        
		mHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
	           	if (myProgressDialog.isShowing()) {
	                	myProgressDialog.dismiss();
	            }
	           	 
	           	// Check if bluetooth connection was made to selected device
	            if (msg.what == 1) {
	            	updateTunerWithNewSettings();
	            }else {
	            	//TODO Connection failed
	            	failToast.show();
	            	finish(); 
	                return; 
	            }
            }
        };
        
        dividerDecButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//TODO Reduce divider by one, need to limit range
				dividerRatio--;
				unitUpdateState();
				updateTunerWithNewSettings();
			}
		});
        
        dividerIncButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//TODO Increase divider by one, need to limit range
				dividerRatio++;
				unitUpdateState();
				updateTunerWithNewSettings();
			}
		});
		
		frequencyBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				updateTunerWithNewSettings();
			}
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				// Set divider according to range and progress bar value
				lastProgressBarValue = progress;
				updateState(progress);	
			}
		});
		
		bandRadioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				if (checkedId == R.id.radio0) {
					lowerLimitText.setText(RANGE_START + " MHz");
					upperLimitText.setText(RANGE_MID + " MHz");
					bandText.setText("Low Band: 00101");
					selectedBand = 5;
					updateState(lastProgressBarValue);
					updateTunerWithNewSettings();
				}else if (checkedId == R.id.radio1) {
					lowerLimitText.setText(RANGE_MID + " MHz");
					upperLimitText.setText(RANGE_HI + " MHz");
					bandText.setText("Mid Band: 01001");
					selectedBand = 9;
					updateState(lastProgressBarValue);
					updateTunerWithNewSettings();
				}else {
					lowerLimitText.setText(RANGE_HI + " MHz");
					upperLimitText.setText(RANGE_END + " MHz");
					bandText.setText("High Band: 01100");
					selectedBand = 12;
					updateState(lastProgressBarValue);
					updateTunerWithNewSettings();
				}
			}
			
		});
		
		updateTunerButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//TODO updateTunerWithNewSettings();
				write((byte)240);
			}
		});
		
		// Everything is up and running, try to connect to a device
		connect();
	}
	
	public void unitUpdateState() {
		double frequency = (dividerRatio / 16.0) - IF_FREQUENCY;
		DecimalFormat df = new DecimalFormat("###.##");
		frequencyText.setText("Frequency: " + df.format(frequency));
		dividerText.setText("Divider Value: " + dividerRatio);
	}
	
	public void updateState(int progress) {
		double freq = RANGE_START;
		
		switch(selectedBand) {
		case 5: {
			freq = RANGE_START + (progress/100.0) * (RANGE_MID - RANGE_START);
		}break;
		case 9: {
			freq = RANGE_MID + (progress/100.0) * (RANGE_HI - RANGE_MID);
		}break;
		case 12: {
			freq = RANGE_HI + (progress/100.0) * (RANGE_END - RANGE_HI);
		}break;
		}
		dividerRatio = (int) (16 * (freq + IF_FREQUENCY));
		
		DecimalFormat df = new DecimalFormat("###.##");
		frequencyText.setText("Frequency: " + df.format(freq));
		dividerText.setText("Divider Value: " + dividerRatio);
	}
	
	public void updateTunerWithNewSettings() {
		byte dividerMSB = (byte)(dividerRatio>>8);
		byte dividerLSB = (byte)dividerRatio;
		
		write(selectedBand);
		write(dividerMSB);
		write(dividerLSB);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	/** Thread used to connect to a specified Bluetooth Device */
    public class ConnectThread extends Thread {
   	private String address;
   	private boolean connectionStatus;
   	
		ConnectThread(String MACaddress) {
			address = MACaddress;
			connectionStatus = true;
   	}
		
		public void run() {
   		// When this returns, it will 'know' about the server, 
           // via it's MAC address. 
			try {
				BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
				
				// We need two things before we can successfully connect 
	            // (authentication issues aside): a MAC address, which we 
	            // already have, and an RFCOMM channel. 
	            // Because RFCOMM channels (aka ports) are limited in 
	            // number, Android doesn't allow you to use them directly; 
	            // instead you request a RFCOMM mapping based on a service 
	            // ID. In our case, we will use the well-known SPP Service 
	            // ID. This ID is in UUID (GUID to you Microsofties) 
	            // format. Given the UUID, Android will handle the 
	            // mapping for you. Generally, this will return RFCOMM 1, 
	            // but not always; it depends what other BlueTooth services 
	            // are in use on your Android device. 
	            try { 
	                 btSocket = device.createRfcommSocketToServiceRecord(SPP_UUID); 
	            } catch (IOException e) { 
	            	connectionStatus = false;
	            } 
			}catch (IllegalArgumentException e) {
				connectionStatus = false;
			}
           
           // Discovery may be going on, e.g., if you're running a 
           // 'scan for devices' search from your handset's Bluetooth 
           // settings, so we call cancelDiscovery(). It doesn't hurt 
           // to call it, but it might hurt not to... discovery is a 
           // heavyweight process; you don't want it in progress when 
           // a connection attempt is made. 
           mBluetoothAdapter.cancelDiscovery(); 
           
           // Blocking connect, for a simple client nothing else can 
           // happen until a successful connection is made, so we 
           // don't care if it blocks. 
           try {
                btSocket.connect(); 
           } catch (IOException e1) {
                try {
                     btSocket.close(); 
                } catch (IOException e2) {
                }
           }
           
           // Create a data stream so we can talk to server. 
           try { 
           	outStream = btSocket.getOutputStream(); 
           } catch (IOException e2) {
           	connectionStatus = false;
           }
           
           // Send final result
           if (connectionStatus) {
           	mHandler.sendEmptyMessage(1);
           }else {
           	mHandler.sendEmptyMessage(0);
           }
		}
    }
    
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
   	 switch (requestCode) {
        case REQUEST_CONNECT_DEVICE:
       	 // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
           	// Show please wait dialog
				myProgressDialog = ProgressDialog.show(this, getResources().getString(R.string.pleaseWait), getResources().getString(R.string.makingConnectionString), true);
				
           	// Get the device MAC address
       		deviceAddress = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
       		// Connect to device with specified MAC address
               mConnectThread = new ConnectThread(deviceAddress);
               mConnectThread.start();
               
            }else {
           	 // Failure retrieving MAC address
           	 Toast.makeText(this, R.string.macFailed, Toast.LENGTH_SHORT).show();
            }
            break;
        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                // Bluetooth is now enabled
            } else {
                // User did not enable Bluetooth or an error occured
                Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
    
    public void write(byte data) {
   	 if (outStream != null) {
            try {
           	 outStream.write(data);
            } catch (IOException e) {
            }
        }
    }
    
    public void emptyOutStream() {
   	 if (outStream != null) {
            try {
           	 outStream.flush();
            } catch (IOException e) {
            }
        }
    }
    
    public void connect() {
   	 // Launch the DeviceListActivity to see devices and do scan
        Intent serverIntent = new Intent(this, DeviceListActivity.class);
        startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
    }
    
    public void disconnect() {
   	 if (outStream != null) {
   		 try {
   	 			outStream.close();
   	 		} catch (IOException e) {
   	 		}
   	 } 
    }

}
