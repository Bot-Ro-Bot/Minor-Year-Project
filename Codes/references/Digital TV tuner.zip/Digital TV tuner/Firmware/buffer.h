
#define BUFFERSIZE 10		// Keep below 127

#include <avr/io.h>
#include <avr/interrupt.h>

volatile uint8_t usartBuffer[BUFFERSIZE];	// FIFO stack
volatile uint8_t writeIndex, currentIndex;

// Gets the most recent element from the buffer
uint8_t popFromBuffer(void);
// Add a new element to the buffer
void bufferInsert(uint8_t data);