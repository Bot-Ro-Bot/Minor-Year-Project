/*************************************************************

TV Tuner controller for I2C compatible tuners.
USART commands received are routed directly to the tuner.

SDA: PD4
SCL: PD5

Project: TV Tuner Controller
MCU Type: ATtiny2313
Clock: 4,096MHz

Data Types:

int8_t - Signed Char 
uint16_t - Unsigned Int 
uint32_t - Unsigned Long 
int64_t - Signed Long Long

(signed/unsigned) char - 1 byte 
(signed/unsigned) short - 2 bytes 
(signed/unsigned) int - 2 bytes 
(signed/unsigned) long - 4 bytes 
(signed/unsigned) long long - 8 bytes 
float - 4 bytes (floating point) 
double - alias to float

************************************************************/

// Last bit of address sets R/W mode.
// Last bit (LSB) = 0 for WRITE, 1 for READ.
#define tunerAddress 0b11000010
#define SDA PD3
#define SCL PD4
#define LED PD5

// USART definitions
#define USART_BAUDRATE 9600 
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)

// EEPROM addresses
#define BAND_ADR 0
#define DIVM_ADR 1
#define DIVL_ADR 2

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include "buffer.h"
#include <avr/eeprom.h>

// Writes a byte using I2C, only call from within write2tuner function
uint8_t writeI2Cbyte(uint8_t data) {
uint8_t i;
//MSB is sent first
for(i=0; i<8; i++){
	if (data & (128>>i)) {
		PORTD |= (1<<SDA);		// Set Data bit
	}else{
		PORTD &= ~(1<<SDA);	// Clear Data bit
	}
	PORTD |= (1<<SCL);		// Set SCL High
	_delay_us(5);			// Wait for a clock cycle
	PORTD &= ~(1<<SCL);	// Set SCL low
	_delay_us(5);			// Wait for a clock cycle
	}
	
	// Acknowledgment
	DDRD &= ~(1<<SDA);		// Release SDA
	PORTD |= (1<<SCL);		// Set SCL High
	_delay_us(5);			// Wait for a clock cycle
	
	// Check that receiver acknowledges
	if (PIND & (1<<SDA)) return 0;
	
	PORTD &= ~(1<<SCL);	// Set SCL low
	_delay_us(5);			// Wait for a clock cycle
	DDRD |= (1<<SDA);		// Set SDA to output
	
	return 1;
	
}

// Write a full set of data to the TV tuner
// Format: Start - Adb - Ack - Db1 - Ack - Db2 - Ack - Cb1 - Ack - Cb2 - Ack - Stop
uint8_t write2tuner(uint8_t address, uint8_t dividerH, uint8_t dividerL, uint8_t controlH, uint8_t controlL) {
uint8_t checksum = 0;

// Start bit (High to low transistion on SDA, while SCL is pulled high)
DDRD |= (1<<SDA);		// Set SDA to output
PORTD &= ~(1<<SDA);	// Set SDA low
_delay_us(10);			// Wait for a clock cycle

DDRD |= (1<<SCL);		// Set SCL as output
PORTD &= ~(1<<SCL);	// Set SCL low

// Transmitt Data bytes
checksum += writeI2Cbyte(address);
checksum += writeI2Cbyte(dividerH);
checksum += writeI2Cbyte(dividerL);
checksum += writeI2Cbyte(controlH);
checksum += writeI2Cbyte(controlL);

// Stop bit (Low to High transistion on SDA, while SCL is pulled high)
DDRD &= ~(1<<SCL);		// Set SCL as input
_delay_us(10);			// Wait for a clock cycle
PORTD |= (1<<SDA);		// Set SDA low
_delay_us(10);			// Wait for a clock cycle
DDRD &= ~(1<<SDA);		// Set SDA to input

if (checksum == 0) {
	// Successful transmission
	return 1;
}else{
	// Acknowlegde not received
	return 0;
	}
}

// Derp function to write to the tuner, with some preset values
void writeTuner(uint16_t freq, uint8_t band) {
	write2tuner(tunerAddress, (freq>>8), freq, 0b10001110, band);
}

// Initialize USART Module
void USART_Init(void) {
	//Enable Receiver and Interrupt on receive complete
	UCSRB |= (1 << RXEN)|(1<<RXCIE);
	//Set data frame format: asynchronous mode,no parity, 1 stop bit, 8 bit size
	UCSRC = (0<<UMSEL)|(0<<UPM1)|(0<<UPM0)|(0<<USBS)|(1<<UCSZ1)|(1<<UCSZ0);

	// Load lower 8-bits of the baud rate value into the low byte of the UBRR register 
	UBRRL = BAUD_PRESCALE;
	// Load upper 8-bits of the baud rate value into the high byte of the UBRR register 
	UBRRH = (BAUD_PRESCALE >> 8);
}

// USART Received Data Complete interrupt service routine
ISR(USART_RX_vect) {
	// Place the USART contents in the buffer, so it can be handled later
	bufferInsert(UDR);
}

int main(void) {
uint8_t state, data, bandSelect;
uint16_t dividerRatio;

// PORTD Initialization, SCL and SDA must be high impedance (inputs) when not in use
DDRD = (1<<LED);
PORTD = 0xFF;
PORTD &=~(1<<LED);

// Initialize USART module
USART_Init();

// Initialize USART buffer
writeIndex = 0;
currentIndex = 0;

// State machine for byte handling
state = 0;

// Initialize with values stored in EEPROM
bandSelect = eeprom_read_byte((uint8_t*)BAND_ADR);
dividerRatio = eeprom_read_byte((uint8_t*)DIVM_ADR);
dividerRatio = dividerRatio << 8;
dividerRatio |= eeprom_read_byte((uint8_t*)DIVL_ADR);
if (bandSelect == 0) bandSelect = 0b101;
if (dividerRatio == 0) dividerRatio = 1880;
writeTuner(dividerRatio, bandSelect);

// BLink LED
PORTD |= (1<<LED);
_delay_ms(700);
PORTD &=~(1<<LED);

// Enable global interrupts
sei();

// Check USART buffer for data, write to tuner.
while(1) {
	// Slowly increase listening range, through FM channels.
	// Check for new data in the USART buffer
	if (writeIndex != currentIndex) {
		// Work on the data
		data = popFromBuffer();
		
		// Need three bytes of data before sending new tuner settings, return current state
		switch(state) {
			case 0:{
				// First data byte received (frequency band)
				// Only permitted to have certain values
				// Else, it may be a store command
				if (data == 0b11110000) {
					eeprom_write_byte((uint8_t*)BAND_ADR, bandSelect);
					eeprom_write_byte((uint8_t*)DIVM_ADR, (dividerRatio>>8));
					eeprom_write_byte((uint8_t*)DIVL_ADR, dividerRatio);
					state = 0;
				}else {
					PORTD |= (1<<LED);	
					bandSelect = data;
					state = 1;
				}
			}break;
			case 1:{
				// Second data byte received (MSB of divider)
				dividerRatio = data;
				dividerRatio = (dividerRatio << 8);
				state = 2;
			}break;
			case 2:{
				// Last data byte received (LSB of divider)
				dividerRatio |= data;
				// Ship it out
				writeTuner(dividerRatio, bandSelect);
				state = 0;
				//PORTD |= (1<<LED);	
				//_delay_ms(200);
				PORTD &=~(1<<LED);
			}break;
			default: state = 0;
		}
	}
};
	
return 1;
}