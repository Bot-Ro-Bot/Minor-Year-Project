
#include "buffer.h"

uint8_t popFromBuffer(void) {
	uint8_t temp;
	
	// Pop a byte from the stack, in an atomic action
	cli();
	temp = usartBuffer[currentIndex];
	currentIndex++;
	if (currentIndex >= BUFFERSIZE) {
		currentIndex = 0;
	}
	sei();
	
	return temp;
}

void bufferInsert(uint8_t data) {
	// This must be done atomically
	cli();
	usartBuffer[writeIndex] = data;
	writeIndex++;
	if (writeIndex >= BUFFERSIZE) {
		writeIndex = 0;
	}
	sei();
}