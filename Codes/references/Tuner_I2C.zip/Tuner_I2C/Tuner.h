#ifndef TUNER_H_
#define TUNER_H_

#include "i2c.cpp"

#define tunerAddress 0b11000010


uint8_t write2tuner(uint8_t address, uint8_t dividerH, uint8_t dividerL, uint8_t controlH, uint8_t controlL) 
{
uint8_t checksum = 0;
// Start bit (High to low transistion on SDA, while SCL is pulled high)
DDRD |= (1<<SDA);		// Set SDA to output
PORTD &= ~(1<<SDA);		// Set SDA low

_delay_us(10);			// Wait for a clock cycle

DDRD |= (1<<SCL);		// Set SCL as output
PORTD &= ~(1<<SCL);		// Set SCL low

// Transmitt Data bytes

checksum += writeI2Cbyte(address);

checksum += writeI2Cbyte(dividerH);

checksum += writeI2Cbyte(dividerL);

checksum += writeI2Cbyte(controlH);

checksum += writeI2Cbyte(controlL);

// Stop bit (Low to High transistion on SDA, while SCL is pulled high)
DDRD &= ~(1<<SCL);		// Set SCL as input
_delay_us(10);			// Wait for a clock cycle
PORTD |= (1<<SDA);		// Set SDA low
_delay_us(10);			// Wait for a clock cycle
DDRD &= ~(1<<SDA);		// Set SDA to input

	if (checksum == 0) 
	{
		// Successful transmission
		return 1;
	}
	else
	{
	// Acknowlegde not received
		return 0;
	}
}
// Derp function to write to the tuner, with some preset values

void writeTuner(uint16_t freq, uint8_t band) 
{
	write2tuner(tunerAddress, (freq>>8), freq, 0b10001110, band);
}
#endif