/*************************************************************
TV Tuner controller for I2C compatible tuners.
USART commands received are routed directly to the tuner.
SDA: PD4
SCL: PD5
Project: TV Tuner Controller
MCU Type: ATtiny2313
Clock: 4,096MHz
Data Types:
int8_t - Signed Char 

uint16_t - Unsigned Int 

uint32_t - Unsigned Long 

int64_t - Signed Long Long

(signed/unsigned) char - 1 byte 

(signed/unsigned) short - 2 bytes 

(signed/unsigned) int - 2 bytes 

(signed/unsigned) long - 4 bytes 

(signed/unsigned) long long - 8 bytes 

float - 4 bytes (floating point) 

double - alias to float
************************************************************/
// Last bit of address sets R/W mode.

// Last bit (LSB) = 0 for WRITE, 1 for READ.


#define SDA PD3
#define SCL PD4
#define LED PD5



// USART definitions

#define USART_BAUDRATE 9600 
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)



// EEPROM addresses
#define BAND_ADR 0
#define DIVM_ADR 1
#define DIVL_ADR 2



#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include <avr/eeprom.h>

#include "i2c.cpp"
#include "Tuner.h"
#include "usart.cpp"

//global varaiable used
extern char receivedByte;

int main(void) 
{
uint8_t state, data, bandSelect;
uint16_t dividerRatio;

// PORTD Initialization, SCL and SDA must be high impedance (inputs) when not in use
DDRD = (1<<LED);
PORTD = 0xFF;
PORTD &=~(1<<LED);



// Initialize USART module
USART_Init();
// Initialize USART buffer
int writeIndex = 0;
int currentIndex = 0;

// State machine for byte handling
state = 0;
// Initialize with values stored in EEPROM
//send your own value
// bandSelect = eeprom_read_byte((uint8_t*)BAND_ADR);
// dividerRatio = eeprom_read_byte((uint8_t*)DIVM_ADR);
// dividerRatio = dividerRatio << 8;
// dividerRatio |= eeprom_read_byte((uint8_t*)DIVL_ADR);

bandSelect = 0;
dividerRatio = 0;

if (bandSelect == 0) 
	bandSelect = 0b101;

if (dividerRatio == 0) 
	dividerRatio = 1880;

writeTuner(dividerRatio, bandSelect);

// BLink LED
PORTD |= (1<<LED);
_delay_ms(700);
PORTD &=~(1<<LED);



// Enable global interrupts
sei();
// Check USART buffer for data, write to tuner.
while(1) 
{
	// Slowly increase listening range, through FM channels.
	// Check for new data in the USART buffer
	if (writeIndex != currentIndex) {
		// Work on the data
		data = receivedByte;
		// Need three bytes of data before sending new tuner settings, return current state
		switch(state) 
		{
			case 0:
			{
				// First data byte received (frequency band)
				// Only permitted to have certain values
				// Else, it may be a store command
				if (data == 0b11110000) 
				{
					// eeprom_write_byte((uint8_t*)BAND_ADR, bandSelect);
					// eeprom_write_byte((uint8_t*)DIVM_ADR, (dividerRatio>>8));
					// eeprom_write_byte((uint8_t*)DIVL_ADR, dividerRatio);
					state = 0;
				}
				else 
				{
					PORTD |= (1<<LED);	
					bandSelect = data;
					state = 1;
				}
			}
			break;

			case 1:
			{
				// Second data byte received (MSB of divider)
				dividerRatio = data;
				dividerRatio = (dividerRatio << 8);
				state = 2;
			}
			break;

			case 2:
			{
				// Last data byte received (LSB of divider)
				dividerRatio |= data;

				// Ship it out
				writeTuner(dividerRatio, bandSelect);
				state = 0;
				//PORTD |= (1<<LED);	
				//_delay_ms(200);
				PORTD &=~(1<<LED);
			}
			break;
			
			default: 
				state = 0;
		}
	}
}
return 1;
}