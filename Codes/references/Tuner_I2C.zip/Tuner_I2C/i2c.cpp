#ifndef I2C_CPP_
#define I2C_CPP_

#include <avr/io.h>
#include <stdio.h>


#define SDA PD3
#define SCL PD4

uint8_t writeI2Cbyte(uint8_t data)
{
uint8_t i;
//MSB is sent first
	for(i=0; i<8; i++)
	{
		if (data & (128>>i)) 
		{
			PORTD |= (1<<SDA);		// Set Data bit
		}
		else
		{
			PORTD &= ~(1<<SDA);	// Clear Data bit
		}
		PORTD |= (1<<SCL);		// Set SCL High
		_delay_us(5);			// Wait for a clock cycle
		PORTD &= ~(1<<SCL);	// Set SCL low
		_delay_us(5);			// Wait for a clock cycle
	}
	// Acknowledgment
	DDRD &= ~(1<<SDA);		// Release SDA
	PORTD |= (1<<SCL);		// Set SCL High

	_delay_us(5);			// Wait for a clock cycle
	// Check that receiver acknowledges

	if (PIND & (1<<SDA)) 
		return 0;
	PORTD &= ~(1<<SCL);		// Set SCL low
	_delay_us(5);			// Wait for a clock cycle
	DDRD |= (1<<SDA);		// Set SDA to output
	return 1;
}
#endif