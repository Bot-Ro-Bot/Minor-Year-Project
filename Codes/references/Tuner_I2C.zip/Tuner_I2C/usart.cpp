#ifndef USART_CPP_
#define USART_CPP_

#include <avr//io.h>
#include <avr/interrupt.h>

// USART definitions
#define USART_BAUDRATE 9600 
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)

char ReceivedByte;

// Initialize USART Module
void USART_Init(void) 
{
	//Enable Receiver and Interrupt on receive complete
	UCSRB |= (1 << RXEN)|(1<<RXCIE);
	//Set data frame format: asynchronous mode,no parity, 1 stop bit, 8 bit size
	UCSRC = (0<<UMSEL)|(0<<UPM1)|(0<<UPM0)|(0<<USBS)|(1<<UCSZ1)|(1<<UCSZ0);
	// Load lower 8-bits of the baud rate value into the low byte of the UBRR register 
	UBRRL = BAUD_PRESCALE;
	// Load upper 8-bits of the baud rate value into the high byte of the UBRR register 
	UBRRH = (BAUD_PRESCALE >> 8);
}

// USART Received Data Complete interrupt service routine
ISR(USART_RXC_vect) 
{
	// Place the USART contents in the buffer, so it can be handled later
	// bufferInsert(UDR);
	ReceivedByte = UDR;
}


#endif