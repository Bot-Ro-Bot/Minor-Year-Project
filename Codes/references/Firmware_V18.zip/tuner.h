/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: tuner.h                                                */
/*                                                                       */
/*  Revision: V1.0     Date: 10.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Prototype definitions for source c-files                    */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 16.04.2001
// Updated by: Chr. Monstein 30.11.2002 adapted to Callisto
// Updated by: Chr. Monstein 10.12.2002 synthesier_resolution changed from KHz->MHz
// Updated by: Meyer Hansueli 02.02.2004 new function tuner  
// Updated by: Chr. Monstein  21.09.2010 Anpassungen an 10Bit HAM

/*-----------------------------------------------------------------------*/

#ifndef tuner_h
#define tuner_h

/*-----------------------------------------------------------------------*/

#define SCL PORTD.4 			// SCL is located on PORTD.Bit4 of STK-500 
#define SDA PORTD.5 			// SDA is located on PORTD.Bit5 of STK-500    

#define synthesizer_resolution 0.0625   // 4MHz/64 ->PLL: 8 x 7.8125KHz = 62.5KHz  

//#define RX_IF (10.70+27.0) 		// IF-frequency #1 = IF-frequency #2 + Quarz-frequency [MHz]
#define RX_IF (10.70+25.43) 		// IF-frequency #1 = IF-frequency #2 + Quarz-frequency [MHz]
#define PopularRadio 105.600    	// Receiving frequency Radio Z�richsee on CableCOM [MHz]

void SetTuner(float actualfrequency);   // set tuner to new frequency (MHz)
void I2C_Init(void); 			// just wait a bit ....
void I2C_Start(void); 		
void I2C_Stop(void);
void I2C_SDA(Byte arg);
void I2C_SCL(Byte arg);



#endif

/*-----------------------------------------------------------------------*/