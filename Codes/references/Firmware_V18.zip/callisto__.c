/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: callisto.c                                             */
/*                                                                       */
/*  Revision: V1.0     Date: 30.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Mainprogram of frequency agile Radiospectrometer CALLISTO   */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein  26.11.2002 Begin
// Updated by: Chr. Monstein  02.12.2002 new flags introduced
// Updated by: Chr. Monstein  10.12.2002 new version
// Updated by: Chr. Monstein  27.12.2002 heater flags introduced
// Updated by: Chr. Monstein  28.12.2002 Test-table with tuner-frequencies introduced
// Updated by: Chr. Monstein  30.12.2002 adc-transmission without terminator
// Updated by: Meyer Hansueli 01.04.2003 Changed from At90S8535 to ATmega16 (11.0592MHz) 
// Updated by: Meyer Hansueli 12.05.2003 band barrier setting fot tuner0 and tuner1 introduced
// Updated by: Meyer Hansueli 01.07.2003 Watchdog introduced   
// Updated by: Meyer Hansueli 11.10.2003 observation mode in the mainloop introduced      
// Updated by: Chr. Monstein  17.08.2010 Spannungsteiler angepasst fuer HAM-Version
// Updated by: Chr. Monstein  21.09.2010 Anpassungen an 10Bit HAM
// Updated by: Chr. Monstein  21.06.2011 delete idlecount   
// Updated by: chr. Monstein  02.03.2012 new Quartz 25,43 MHz
//-------------------------------------------------------------------------------------
// Include files
#include <stdio.h>  
#include <string.h> 
#include <delay.h>
#include <spi.h>  
#include <mega16.h> 
#include <stdlib.h>
  
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"  
#include "setfopa.h"  


//-------------------------------------------------------------------------------------
// Global Variables (Public)
char initial[] = "e-Callisto ETH Zurich"; // < 20 Bytes! 
//char version[] = "V1.6, 2010-08-17";              
//char version[] = "V1.7, 2011-06-21";              
char version[] = "V1.8 / 2012-03-02";              

bit debug;          	// shall we send acknowledge back to the host? 
bit adc_command=false;  // transmit adc value or not
bit softtrigger;    	// software triggered ADC?   
bit timertrigger;   	// timer pacer triggered ADC?
bit externtrigger;  	// external triggered ADC?      
bit continuous;     	// steady recording?
bit transferdata;   	// transfer data from mainboard to host?   
bit stoptransfer;	  	// stop the transfer in the interrupt routine   
bit eot_flag;           // send eot character when transmission has finished
bit send_result;

extern bit rx_buffer_overflow; //from rs232.c file imported
extern Byte rx_counter; //from rs232.c file imported   
extern Word adc_value;	// import from adc.c                         
extern Word low_band_max; // import from command.c 	
extern Word mid_band_max;  // import from command.c 	
extern Word high_band_max; // import from command.c  

Byte set_once;           // don't send the first two results
Byte not_send;           // don't send the first two results
Byte send_once;          // import from timer.c    
Byte FPUcodex;           // import from callisto.c 
bit reset_flag;	         // used to test the watchdog   
Word result;             // state machine tuner value

Word counter;       	 // count the measured frequencies used in command.c (GH)
//Word idlecount;     	 // something to count
Word number_count; 	 // count the measured frequencies
Word stepcount;          // count the integration steps
Word measuringtime; 	 // delay between software triggered measurements


float uin;       		// used to read the system voltages, temperature and humidity
float rht;       		// used to read the system voltages, temperature and humidity 
float frequency; 		// Actual frequency  

eeprom float rx_init=(PopularRadio); // Power up with most popular receiving frequency
eeprom float if_init=(RX_IF); 	// Power up if-center-frequency    

//-------------------------------------------------------------------------------------
void main( void ) // Testprogram to take control of ATmega16-functions
{                        
	char runcomm [RX_BUFFER_SIZE+1] = ""; 	// space MUST be reserved!
	char data = '\0';      				// Buffer for one single incoming byte to work with
	char tmp[16]="";  				// string buffer  
	Byte cmdcount = 0;     				// counts the incoming bytes from RS232 port 
	debug         = false; 				// per default no acknowledge to the host
	softtrigger   = false; 				// per default no software triggered ADC   
	timertrigger  = false; 				// per default no pacer timer triggered ADC
	externtrigger = false; 				// per default no external triggered ADC 
 	stoptransfer  = false;                          // per default transfer data
	transferdata  = true;  		                // per default don't transfer data from mainboard to host 	 			
	continuous    = false; 				// per default no recording initially
	eot_flag      = false; 				// don't send the eot character      
	send_once     = true;                           // send the eot character once
	reset_flag    = true;				// watchdog on at start	
	set_once      = true;                           // send one result per step in the interrupt
	not_send      = false;                          // don't send the first two bytes of main process
	send_result=false;                              // no data sending at start
	measuringtime = 0;     			        // per default no delay, full speed during design phase, later -> 1msec	
	
	low_band_max=171; 			        // Init band barriers of tuner
	sprintf(tmp,"%u",low_band_max);   
	EEPROM_write(address_lowband, tmp);             // write  to internal EEPROM
 	mid_band_max=450;  			        // Init band barriers of tuner
  	sprintf(tmp,"%u",mid_band_max);   
	EEPROM_write(address_midband, tmp);             // write  to internal EEPROM
	high_band_max=863;                              // Init band barriers of tuner
	sprintf(tmp,"%u",high_band_max);   
	EEPROM_write(address_highband, tmp);            // write  to internal EEPROM
	
	InitDigital_IO(); 				// Set I/O-ports and bits     	   	
	InitUSART(); 					// Set the baudrate to 115,200 bps using a 11.0592MHz crystal
	InitADC(); 					// ADC initialization, Clock frequency: 57.656 kHz, Interrupts: On  
	I2C_Init();                                     // Prepare I2C-bus
	Init_Watchdog(); 				// Watchdog Timer Initialization	
	TriggerADC(1);                                  // triger ADC for the first time	
 	delay_ms(100); 					// not neccessary for <= 19'200Baud 	
 	TriggerADC(0);                                  // triger ADC for the first time

	#asm("sei()") 					// Enable interrupts => enable USART interrupts
                    
 	printf("$CRX:%s\r",initial);                    // Start message (title)
  	printf("$CRX:%s\r",version); 	                // Start message (version)  		 	
	
 	SetTuner(rx_init);  		                // Set tuner to the most popular radio transmitter
 
	while(1)  					// Do, as long as power is available...
	{           
		if (rx_counter>0) 			// if data in RX buffer
		{
			data = getchar() & 0x7F; 	// Store the received character
			if (data==carriage_return) 	// Transmission terminator available?
			{    
				runcomm[cmdcount]='\0'; // Terminate running command
				cmdcount=0; 			// Reset command byte counter
				CommandInterpreter(runcomm); 	// Interpretation of command string
				if (debug)
				{
					printf("$CRX:Command=<%s>\r",runcomm); // Message to host
				}
				runcomm[0]='\0'; 	 // Delete and terminate running command 
			}
			else
			{
				runcomm[cmdcount++]=data; // put next character into tar-command-string
				if (rx_buffer_overflow>0) //(cmdcount>UART_RX_BUFFER_SIZE) 
				{
					printf("$CRX:RX_buffer_overflow\r"); 
					cmdcount = 0; 	          // Reset string because it is too long 
					rx_buffer_overflow = 0;   // reset error
				  	runcomm[cmdcount] = '\0'; // Kill running command
				}
			}              
		} // end if (DataInReceiveBuffer())
		else
		{     
			// idle
		}
		if (send_result) 
		{
		    printf("%04X",result);      // 10bit
		    send_result = false;
		}  			
	} // end for( ; ; ) 
}
//-------------------------------------------------------------------------------------
/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: digital_io.c                                           */
/*                                                                       */
/*  Revision: V1.0     Date: 30.11.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Initializes, Sets and Resets bits on Digital Input/Output   */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 26.11.2002  
// Updated by: Chr. Monstein 30.11.2002
// Updated by: Chr. Monstein 30.11.2002
// Updated by: Meyer Hasnueli 08.04.2003 SPI outputs set
//-------------------------------------------------------------------------------------

#include <mega16.h>
#include <stdio.h> 
#include <stdlib.h>
   
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"

//-------------------------------------------------------------------------------------
void InitDigital_IO(void)
{
	// Data Direction Register Port C
	DDRC=0xFF; 				// Port C all bits output for debugging via STK500
 	PORTC=0xFF; 				// set all LEDs dark...	
 	
 	PORTD=0x3F; 				// Port D initialization
	DDRD=0xF3;                              // Port PD7 PWM output
      
 	// Data Direction Register Port B
	// SPI initialization
	// SPI Type: Master
	// SPI Clock Rate: 2764.800 kHz relates to a MHz crystal
	// SPI Clock Phase: Cycle Half
	// SPI Data Order: MSB First	
 	DDRB=0xBC; 	//SPI Bus I/O, SCK=out, MISO=IN, MOSI=out, CS=out
 	SPCR=0x50; 
	PORTB=0xB7;   
        
	
	// Timer/Counter 2 initialization
	// Clock source: System Clock
	// Clock value: 11059.200 kHz
	// Mode: Phase correct PWM top=FFh
	// OC2 output: Non-Inverted PWM
	ASSR=0x00;
	TCCR2=0x61;
	TCNT2=0x00;
	OCR2=0x00;	
}
//-------------------------------------------------------------------------------------
/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: tuner.c                                                */
/*                                                                       */
/*  Revision: V1.2     Date: 10.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Transmits i2c-signals to the Philips TV-tuner CD1316        */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 16.04.2001
// Updated by: Chr. Monstein 30.11.2002 Adaption to Callisto
// Updated by: Chr. Monstein 10.12.2002 synthesizer_resolution KHz->MHz
// Updated by: Chr. Monstein 21.09.2010 Anpassungen an 10Bit HAM

//---------------------------------------------------------------------------  
// Include files
#include <mega16.h>
#include <stdio.h> 
#include <stdlib.h>
  
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"

//---------------------------------------------------------------------------
// Global variables import/export
extern Word low_band_max;   			
extern Word mid_band_max;  			
extern Word high_band_max;  

//---------------------------------------------------------------------------
void I2C_Init(void)
{    
   SCL = 1;
   SDA = 1;                  
} 
//---------------------------------------------------------------------------
void I2C_SDA(Byte arg)
{                     
   if (arg)
     SDA = 1;
   else
     SDA = 0;
}
//---------------------------------------------------------------------------
void I2C_SCL(Byte arg)
{                     
   if (arg)
     SCL = 1;
   else
     SCL = 0;
}
//---------------------------------------------------------------------------
void I2C_Start(void) 
{                     
   I2C_SDA(0);
   I2C_SCL(0);
   I2C_SDA(1);
   I2C_SCL(1);
   I2C_SDA(0);
   I2C_SCL(0);
}
//---------------------------------------------------------------------------
void I2C_Stop(void)
{          
   I2C_SDA(0);           
   I2C_SCL(0);
   I2C_SCL(1);
   I2C_SDA(1);           
}
//---------------------------------------------------------------------------
void I2C_Wrbyte(Byte arg) // write 1 byte to device, serial output, MSB first
{                              
    Byte x;
    Byte power = 128;
    for (x=1; x<=8; x++)
    {
       I2C_SDA(0); 
       I2C_SCL(0);
       if ((arg & power) == power)
       {
          I2C_SDA(1);
          I2C_SCL(1);
          I2C_SCL(0);
          I2C_SDA(0);
       }
       else 
       {
          I2C_SDA(0);
          I2C_SCL(1);
          I2C_SCL(0);
       }   
       power = power / 2;
    }   
    // get acknowledge       
    I2C_SCL(1);
    I2C_SCL(0);
}
//---------------------------------------------------------------------------
void SetTuner(float actualfrequency) // set tuner to new frequency
{
    Word divider;
    Byte db1, db2;  			// divider byte 1 and 2
    Byte adb, cb, bb; 			// address byte, control byte 1 and 2

    adb = 128 + 64 + 0; 		// evaluate tuner adress byte 110000xxB
    
    // estimate oscillator divider bytes
    divider=(unsigned int)( (actualfrequency+if_init)/synthesizer_resolution); // MHz->KHz->channel
    db1 = (Byte) (divider / 256); 	// evaluate first data byte
    db2 = (Byte) (divider % 256); 	// evaluate second data byte

    cb = 128 + 64 + 4 + 2; 		// tuner control byte 62.5khz
 
    // bb setting according to oscillator frequency (band select)
    if (actualfrequency <= low_band_max) 	// low band 51-171MHz = 00000001
        bb = 1; 
    else
    {
        if (actualfrequency <= mid_band_max) // mid band 178-450MHz = 00000010
            bb = 2; 
        else 				// high band 458-858MHz = 00000100
            bb = 4; 
    }            
                  
    // Output sequence to device via digital-I/O-Port, send start bit first
    I2C_Start();
    
    I2C_Wrbyte(adb); // Send address byte
    I2C_Wrbyte(db1); // Send divider byte 1
    I2C_Wrbyte(db2); // Send divider byte 2
    I2C_Wrbyte(cb);  // Send control byte
    I2C_Wrbyte(bb);  // Send band-switch byte
    
    // Send stopp bit
    I2C_Stop();
}
//---------------------------------------------------------------------------












/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: adc.c                                                  */
/*                                                                       */
/*  Revision: V1.0     Date: 30.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: AnalogToDigital-Converter Radiospectrometer CALLISTO        */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 30.11.2002
// Updated by: Chr. Monstein 09.12.2002 ADC-format changed form ASCII mV to HEX &
// -ADC samples 32 times faster
// Updated by: Chr. Monstein 15.12.2002 serial output via printf() instead of TransmitString()
// Updated by: Chr. Monstein 28.12.2002 adc transmission with 4 different formats
// Updated by: Chr. Monstein 30.12.2002 test adc transmission without terminator [SendString()]
// Updated by: Chr. Monstein 03.04.2003 changed from AT90S5835 to ATmega16    
// Updated by: Meyer Hansueli 05.05.2003 new function implemented READ_ADC   
// Updated by: Meyer Hansueli 07.10.2003 new function Evaluate_ADC
// Updated by: Chr. Monstein: 21.09.2010 // Anpassungen an 10Bit HAM

//-------------------------------------------------------------------------------------
#include <mega16.h>
#include <stdio.h> 
#include <stdlib.h>

#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"  

//-------------------------------------------------------------------------------------
// global data (import/export)
bit adc_ready = false;
Word adc_value; 

extern bit adc_command; // import from callisto.c
extern Byte format;     // import from command.c
extern float frequency; // import from command.c      
extern float uin;       // import from command.c
extern float rht;       // import from command.c

//-------------------------------------------------------------------------------------
void TransmitADC(Word value) 							// Send ADC value to the host (debugging tool)
{
	char temp[12] = ""; 
	Word f_MHz;     							// temporary frequency  
  	float u;                                                
	switch(format) 								// attention: different transmission versions used [TransmitString()/printf())]
	{
		case 0: 								// decimal 10bit
		{
			printf("$CRX:%u\r",value); 
			break;
		}
		case 1: 								// decimal 8bit
		{
			printf("$CRX:%u\r",value/4); 
			break;
		}
		case 2: 								// decimal Millivolt
		{
  			u = (float)value*2500/1024;
  			sprintf(temp,"ADC%u=%umV",ADMUX,(Word)u); // mV
			printf("$CRX:%s\r",temp);
			break;
		}
		case 3: // HEX 8 bit
		{
			sprintf(temp,"%02X",value/4); 	// digit [hex]
			printf("$CRX:%s\r",temp);
			break;
		}     
		case 4: // HEX 8 bit
		{
			sprintf(temp,"%02X",value/4); 	// digit [hex] 8 bit no carriage return and no $CRX:
			printf("%s",temp); 
			break;
		}           
		case 5: 						// frequency+decimal Millivolt
		{
  			u = ((float)value)*2500.0/1024.0; 
			f_MHz = (Word)frequency;
			sprintf(temp,"%03u.%03u,%u",f_MHz,(Word)((frequency-f_MHz)*1000.0+0.5),(Word)u); // MHz
			printf("$CRX:%s\r",temp);
			break;
		} 
	}
	adc_command = false; 						// prevent another transmission    
}    
//-------------------------------------------------------------------------------------
void InitADC(void) 		// ADC initialization, Clock frequency: xyz kHz, Interrupts: On
{
	ADMUX  = ADC_VREF_TYPE;
       	ADCSRA = 0x8E;            // 0x8E=173kHz;0x8C=346kHz clock frequency (11.0952MHz/16)   
	SFIOR &= 0xEF;            // enable high speed mode ADC
	SFIOR |= 0x10;  
}
//-------------------------------------------------------------------------------------
Word Evaluate_ADC(Byte trigger_number)  
{
	TriggerADC(trigger_number);
    	do	
    	{ 
	} while (!adc_ready); // wait until adc converting has finished
	adc_value = ADCW;   
        return adc_value;
}
//-------------------------------------------------------------------------------------
void TriggerADC(Byte channel)
{
	adc_ready = false;   		// to syncronize read process of ADC 
	ADMUX = channel;     		// Select ADC input 0  or ADC input 1
	ADCSRA |= 0x40;     		// Start AD conversion
}
//-------------------------------------------------------------------------------------
interrupt [ADC_INT] void adc_isr(void) // ADC interrupt service routine
{       
	adc_ready = true; 
}
//-------------------------------------------------------------------------------------






















/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: rs232.c                                                */
/*                                                                       */
/*  Revision: V1.4     Date: 30.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Receives and Transmits data via Interrupt on UART ATmega16  */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 15.11.2002  Idea taken from AVR306
// Updated by: Chr. Monstein 02.12.2002  commands M, T introduced, unit name changed
// Updated by: Chr. Monstein 10.12.2002  commands L introduced, Px changed
// Updated by: Chr. Monstein 15.12.2002  status command optimized
// Updated by: Chr. Monstein 16.12.2002  commands CPb and SPb included
// Updated by: Chr. Monstein 27.12.2002  command interpreter moved to command.c
// Updated by: Chr. Monstein 30.12.2002  new function SendString() [no terminator]
// Updated by: Hansueli Meyer 09.04.2003 changed from At90S8535 to ATmega16
//-------------------------------------------------------------------------------------
// Include files  
#include <stdio.h>   
#include <string.h> 
#include <stdlib.h>
#include <delay.h> 
#include <mega16.h> 

#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h" 
//-------------------------------------------------------------------------------------
// USART Receiver buffer
char rx_buffer[RX_BUFFER_SIZE];
unsigned char rx_wr_index,rx_rd_index,rx_counter;
bit rx_buffer_overflow;  // This flag is set on USART Receiver buffer overflow
//-------------------------------------------------------------------------------------
// USART Transmitter buffer
char tx_buffer[TX_BUFFER_SIZE];
unsigned char tx_wr_index,tx_rd_index,tx_counter;
//-------------------------------------------------------------------------------------
void InitUSART(void)	// USART initialization, USART Mode: Asynchronous	
{
	UCSRA = 0x00;
	UCSRB = 0xD8;      	// Communication Parameters: 8 Data, 1 Stop, No Parity
	UCSRC = 0x06;      	// 8bit data communication
	UBRRH = 0x00;      	// USART Receiver: On;  USART Transmitter: On
	UBRRL = baudrate;  	// USART Baud rate: 115200
}
//-------------------------------------------------------------------------------------
// USART Receiver interrupt service routine
#pragma savereg-
interrupt [USART_RXC] void uart_rx_isr(void)
{
	char status,data;
	#asm
    	push r26
    	push r27
    	push r30
    	push r31
    	in   r26,sreg
    	push r26
	#endasm
	status=UCSRA;
	data=UDR;
	if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
   	{
   		rx_buffer[rx_wr_index]=data;
   		if (++rx_wr_index == RX_BUFFER_SIZE) rx_wr_index=0;
   		if (++rx_counter == RX_BUFFER_SIZE)
      	{
      		rx_counter=0;
      		rx_buffer_overflow=1;
      	};
   	};
	#asm
    	pop  r26
    	out  sreg,r26
    	pop  r31
    	pop  r30
    	pop  r27
    	pop  r26
	#endasm
}
#pragma savereg+
//-------------------------------------------------------------------------------------
#ifndef _DEBUG_TERMINAL_IO_
// Get a character from the USART Receiver buffer
#define _ALTERNATE_GETCHAR_
#pragma used+
char getchar(void)
{
	char data;
	while (rx_counter==0);
	data=rx_buffer[rx_rd_index];
	if (++rx_rd_index == RX_BUFFER_SIZE) rx_rd_index = 0;
	#asm("cli")
	--rx_counter;
	#asm("sei")
	return data;
}
#pragma used-
#endif
//-------------------------------------------------------------------------------------
// USART Transmitter interrupt service routine
#pragma savereg-
interrupt [USART_TXC] void uart_tx_isr(void)
{
	#asm
    	push r26
    	push r27
    	push r30
    	push r31
    	in   r26,sreg
    	push r26
	#endasm
	if (tx_counter)
   	{
   		--tx_counter;
     		UDR=tx_buffer[tx_rd_index];
     		if (++tx_rd_index == TX_BUFFER_SIZE) tx_rd_index = 0;
 	};
	#asm
 	pop  r26
 	out  sreg,r26
 	pop  r31
 	pop  r30
 	pop  r27
 	pop  r26
	#endasm
}
#pragma savereg+
//-------------------------------------------------------------------------------------
#ifndef _DEBUG_TERMINAL_IO_
// Write a character to the USART Transmitter buffer
#define _ALTERNATE_PUTCHAR_
#pragma used+
void putchar(char c)
{
	while (tx_counter == TX_BUFFER_SIZE);
	#asm("cli")
	if (tx_counter || ((UCSRA & DATA_REGISTER_EMPTY)==0))
   	{
   		tx_buffer[tx_wr_index] = c;
   		if (++tx_wr_index == TX_BUFFER_SIZE) tx_wr_index = 0;
   		++tx_counter;
   	}
	else UDR = c;
	#asm("sei")
}
#pragma used-
#endif
//------------------------------------------------------------------------------------- 

/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: command.c                                              */
/*                                                                       */
/*  Revision: V1.4     Date: 30.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Receives and Transmits data via Interrupt on USART ATmega16 */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein  27.12.2002 moved form rs232.c into separate file
// Updated by: Chr. Monstein  28.12.2002 debug features deleted to save flash memory
//                                      new command: Format %0...%3
// Updated by: Chr. Monstein  30.12.2002 test: single sweep with terminator only at the end
// Updated by: Hansueli Meyer 03.03.2003 new commands GSx and GAx 
// Updated by: Hansueli Meyer 17.03.2003 new commands FExyz and FRx
// Updated by: Hansueli Meyer 02.04.2003 new commands Lx sweeplenght
// Updated by: Hansueli Meyer 10.04.2003 new commands Ix integration time
// Updated by: Hansueli Meyer 14.04.2003 new commands FSx to set FPU
// Updated by: Hansueli Meyer 10.04.2003 new commands FMx, FLx and FHx tuner barriers
// Updated by: Hansueli Meyer 22.04.2003 new commands GD and GE enable and disable data transfer
// Updated by: Hansueli Meyer 07.05.2003 new commands PM1 and AM1 
// Updated by: Hansueli Meyer 14.05.2003 new commands S0 and S1 start and stop state machine
// Updated by: Hansueli Meyer 10.06.2003 new commands Q0-3 power splitter
// Updated by: Hansueli Meyer 22.07.2003 unused commands removed
// Updated by: Hansueli Meyer 16.10.2003 commands removed PM1 and AM1 
// Updated by: Hansueli Meyer 18.10.2003 new commands removed O0-8 Observation mode
// Updated by: Hansueli Meyer 25.10.2003 some changes in the commands S0 and S1   
// Updated by: Hansueli Meyer 02.12.2003 new command W send the initial and version code   
// Updated by: Hansueli Meyer 26.01.2004 Rx command sends result in switched off debug modus
// Updated by: Chr. Monstein  17.08.2010 Spannungsteiler angepasst fuer HAM-Version
// Updated by: Chr. Monstein  21.09.2010 Anpassungen an 10Bit HAM
// Updated by: Chr. Monstein  21.06.2011 Korrektur IF, debug-bit    
// Updated by: Chr. Monstien  02.03.2012 response to FE now two lines

//-------------------------------------------------------------------------------------
// Include files
#include <stdio.h>   
#include <string.h> 
#include <stdlib.h>
#include <delay.h>
#include <spi.h>
#include <mega16.h>   

#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h" 
#include "setfopa.h"  


//-------------------------------------------------------------------------------------

bit error = false;      // parameter error 
Byte format=4;          // default transmision format 8bit hex


extern bit softtrigger;         // import from callisto.c 
extern bit timertrigger;        // import from callisto.c 
extern bit transferdata;        // import from callisto.c 
extern bit externtrigger;       // import from callisto.c  
extern bit continuous;          // import from callisto.c  
extern bit stoptransfer;	// import from callisto.c   
extern bit adc_ready;           // import from adc.c   
extern bit adc_command;         // import from callisto.c  
extern bit eot_flag;            // import from callisto.c  
extern bit debug;               // import from callisto.c
extern Byte send_once;		// import from timer.c
extern Byte not_send;  

extern Byte FPUcodex;           // import from callisto.c 
extern bit reset_flag;		// import from callisto.c 	

Word sweeplength;               // frequency file length
Word low_band_max;   		  	
Word mid_band_max;  		   	
Word high_band_max;                      
Word pwm_value;   	

extern Word counter;            // import from callisto.c 
extern Word adc_value;          // import from adc.c 
extern Word measuringtime;      // import from callisto.c  
extern Word number_count; 	// import from callisto.c 
extern Word stepcount;          // import from command.c  
	
extern float uin;         	// import from callisto.c 
extern float rht;               // import from callisto.c 
extern float frequency; 		        // Actual frequency   
static volatile char tuner=0;   // Actual tuner address

Word prescaler_value_Syn;	// prescaler value is used in the timer.c init functions (11.0592MHz)		
Word prescaler_value_Asyn;	// prescaler value is used in the timer.c init functions (1MHz)

//-------------------------------------------------------------------------------------
void CommandInterpreter(char *cmd) 	// check incoming commands
{               
  	Byte u;            		// temporary command
  	Byte v;            		// temporary first parameter 
  	Byte w;            		// temporary second parameter
	Byte i;            		// common counter 
	Byte p;            		// common port register
	Word db1;                       // bytes used for the tuner
	Word db2;                       // bytes used for the tuner
	Word cb;                        // bytes used for the tuner
	Word bb;           		// bytes used for the tuner
	Word f_MHz;        		// temporary frequency  MHz
	Word fre_number;                // frequency number = EEPROM address 
	Word eeprom_address;            // used to generate the rigth EEPROM address			                  
	Word sweepcount;   		// used for single sweep   
	Word adc_tuner0;                // temporary saving of the tuner values
        //Word prescaler_value_Syn;	// prescaler value is used in the timer.c init functions (11.0592MHz)		
	//Word prescaler_value_Asyn;	// prescaler value is used in the timer.c init functions (1MHz)
	char temp[28]="";  		// string buffer  
	
	u=cmd[0];    			// save command character                               
	v=cmd[1]-48; 			// evaluate first command parameter (ASCII -> decimal)
	w=cmd[2]-48; 			// evaluate second command parameter (ASCII -> decimal)
	if (u=='A')  			// Read ADC
	{
		switch (v) 		// Evaluate parameter (ADC-channel)
		{
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			{  
				adc_value = Evaluate_ADC(v); // read the ADC_value 
				TransmitADC(adc_value);    
				break; 
			} 
			default: error = true; break; // illegal command
		}
	} 
	else 
	if (u=='C')  // ChargePump respective Clear Port
	{  
		switch (v) 	// Evaluate first parameter 
		{
			case 0:  break; // low phase noise, low speed
			case 1:  break; // high speed and much phase noise
			case 18: // Port B
			{     
				
				switch (w) 	// select bit in CBb
				{
					case 0: PORTB.0=0; break;
					case 1: PORTB.1=0; break;
					case 2: PORTB.2=0; break;
					case 3: PORTB.3=0; break;
					case 4: PORTB.4=0; break;
					case 5: PORTB.5=0; break;
					case 6: PORTB.6=0; break;
					case 7: PORTB.7=0; break;
					default: error = true; break; // illegal command
				}  
				break; 
			}
			case 19: 	// Port C
			{     
				switch (w) 	// select bit in CCb
				{
					case 0: PORTC.0=0; break;
					case 1: PORTC.1=0; break;
					case 2: PORTC.2=0; break;
					case 3: PORTC.3=0; break;
					case 4: PORTC.4=0; break;
					case 5: PORTC.5=0; break;
					case 6: PORTC.6=0; break;
					case 7: PORTC.7=0; break;
					default: error = true; break; // illegal command
				}
				break; 
			}
			case 20: 	// Port D
			{     
				switch (w) 	// select bit in CDb
				{
					case 0: PORTD.0=0; break;
					case 1: PORTD.1=0; break;
					case 2: PORTD.2=0; break;
					case 3: PORTD.3=0; break;
					case 4: PORTD.4=0; break;
					case 5: PORTD.5=0; break;
					case 6: PORTD.6=0; break;
					case 7: PORTD.7=0; break;
					default: error = true; break; // illegal command
				}
				break; 
			}
			default: error = true; break; // illegal command
		}
	} 
	else
	if (u=='D')  // Evaluate Debugmode
	{
		switch (v) 	// Evaluate parameter
		{
			case 0:  debug=false; break; // additional informations off
			case 1:  debug=true;  break; // additional informations on
			default: error=true;  break; // illegal command
		}
		if (debug)
			printf("$CRX:Debugmode on\r"); // Test message
	} 
	else 
	if (u=='f')  // fsx send focus code to set the FOPA
	{    
		switch (v) 	// Evaluate parameter
		{
			case 67: // fsx
			{
				sscanf(cmd,"fs%u",&FPUcodex); //get the sweeplength and send it to the internal EEPROM
				SetFPU((Byte)FPUcodex);				
				break;
			}                     
			default: error = true;  break; 	// illegal command
		}
		if (debug)
			printf("$CRX:FOPAcodex=%u\r",FPUcodex); // Test message
	} 
	else
	if (u=='F')  	// Evaluate frequencystring, set tuner and read and write to external EEPROM
	{   
		switch (v) 		// Evaluate parameter E or R which means writing or reading to EEPROM
		{
			case 0: // Tuner #0
			{
			  	i = 2; 		// ignore command-prefix and tuner address byte
				tuner = 0; 	// first parameter is tuner address
				do     
				{
					temp[i-2]=cmd[i]; // copy 2nd parameter to temporary string
					i++;
				} while (cmd[i]);
				frequency = atof(temp); // make float 
				SetTuner(frequency);  // tuner-address, frequency[MHz]    
				if (softtrigger)
				{
					adc_value = Evaluate_ADC(tuner); // read the ADC_value 
					TransmitADC(adc_value);    
				}
				break;
			}
			case 21: // EEPROM write FExxx,yyy.yyy,mmm (address[fre_number),frequency,modus)
			{	     
				sscanf(cmd,"FE%u,%03u,%03u,%03u,%03u",&fre_number,&db1,&db2,&cb,&bb); //read address
				sprintf(temp,"FE%u%u%u%u%u",fre_number,db1,db2,cb,bb);   
		  	        eeprom_address=(fre_number-1)*8;  //8 byte sent to EEPROM -> EEPROM address 8 times higher first frequency Nr.1
			        eeprom_write_string(eeprom_address,db1,db2,cb,bb);   // write at address x 
				if (debug)
    					printf("$CRX:%s\r",temp); // send frequency to host to check 
				break;
			}
			case 34: // EEPROM read FRxxx (address (number of frequency [fre_number]))
			{
				i = 2; 	// ignore command-prefix and tuner address byte
				do     
				{
			     		temp[i-2]=cmd[i]; // copy 2nd parameter to temporary string
					i++;
				} while (cmd[i]);	
			 	fre_number=atoi(temp); // make integer
			  	eeprom_address=(fre_number-1)*8; //generate the right EEPROM address
			        eeprom_read_float(eeprom_address,&db1,&db2,&cb,&bb); // read frequency at eeprom_address x  
				sprintf(temp,"EEPROM=%03u,%03u,%03u,%03u",(Byte)db1,(Byte)db2,(Byte)cb,(Byte)bb); // MHz 
				if (debug) 
				{
    					//frequency = ((float)(db1*256+db2)*0.0625)-37.75;
    					frequency = ((float)(db1*256+db2)*0.0625)-if_init; // 02.03.2012/cm
    					f_MHz = (Word)frequency;
					printf("$CRX:Frequency=%u.%uMHz\r",f_MHz,(Word)((frequency-f_MHz)*1000+0.5));
					printf("$CRX:%s\r",temp);
    				}
				break;	
			}  
			case 35: // FSxy set FOPA code  
			{     
				sscanf(cmd,"FS%02u",&(Byte)FPUcodex);// read modus (FOPAcode) to set FOPA  
				if (debug)
		  		{
					printf("$CRX:FPUcodex=%u\r",FPUcodex); // send FOPA code to host		
				} 		
				break; 
			}     
			case 28: // FL low_band_max of tuner   test band switching
			{
				sscanf(cmd,"FL%u",&low_band_max); //read address, frequency and modus 
				sprintf(temp,"%u",low_band_max);   
				EEPROM_write(address_lowband, temp); // write
				break;				
			} 	
			case 29: // FM mid_band_max of tuner
			{
				sscanf(cmd,"FM%u",&mid_band_max); //read address, frequency and modus 
				sprintf(temp,"%u",mid_band_max);   
				EEPROM_write(address_midband, temp); // write
				break;				
			} 	
			case 24: // FH high_band_max of tuner
			{
				sscanf(cmd,"FH%u",&high_band_max); //read address, frequency and modus 
				sprintf(temp,"%u",high_band_max);   
				EEPROM_write(address_highband, temp); // write
				break;				
			} 
			
			default: error = true;  break; 		// illegal command
		}	     
	}
	else
	if (u=='G')  // Set the counter and enable or disable the main interrupt
	{
		transferdata = false;
		switch (v) 	// Evaluate parameter
		{
			case 20: // D=GD disable the datatransfer between host and mainboard
			{
				transferdata = true;
				eot_flag = true;				
				break;
			}       
			case 21:// E=GE enable the datatransfer between host and mainboard
			{
				transferdata = false;				
				break;
			}         
			case 35:// S=GS set the interrupt repeat rate 1Hz, 50Hz, 200Hz, 400Hz
			{		  
  				sscanf(cmd,"GS%u",&prescaler_value_Syn); //read address, frequency and modus 
 				break; 
			}           
			case 17:   // A=GA set the interrupt repeat rate 20Hz, 200Hz, 400Hz
			{		  
  				sscanf(cmd,"GA%u",&prescaler_value_Asyn); //read address, frequency and modus 
				break;  
			}                   
			default: error = true;  break; 		// illegal command
		}
	} 
	else  			
	if (u=='L')  // Evaluate sweep Length
	{    
		sscanf(cmd,"L%u",&sweeplength); //get the sweeplength and send it to the internal EEPROM 
		if (debug)
			printf("$CRX:Sweeplength=%u\r",sweeplength); // Test message
	} 
	else  
	if (u=='M')  // Evaluate measuring delay
	{              
		i=1; // ignore command-prefix
		do     
		{
			temp[i-1] = cmd[i]; // copy 1st parameter to temporary string
			i++;
		}while (cmd[i]);
		measuringtime = atoi(temp); // make Word
		if (debug)
			printf("$CRX:MeasuringDelay=%s\r",temp); // Test message
	} 
	else
	if (u=='O')  // Set PWM-value for gain-control
	{              
	  
		sscanf(cmd,"O%u",&pwm_value); //
		OCR2 = pwm_value;  // timer 2, PORT D bit 7
	        if (debug)
	                printf("$CRX:OCR2=%u\r",pwm_value); // send FOPA code to host  				
	} 	
        else
	if (u=='P')  // Evaluate Processmode   
	{     
		switch (v) // Evaluate parameter
		{
			case 0: // Stop 
			{             
				continuous = false;
				if (debug)
					printf("$CRX:P0=Stop recording\r"); // Test message
				break; 
			}
			case 1: // continous recording
			{
				continuous = true;
				if (debug)
					printf("$CRX:P1=Start recording\r"); // Test message
				break;
			}
			case 2: // Single sweep
			{                         			
				if (debug) 
					printf("$CRX:P2=Start single sweep\r"); // Test message
				sweepcount = 0;
				do
				{     
					frequency = frequency + synthesizer_resolution; // test frequency [TBD]
					SetTuner(frequency);  // tuner-address, frequency[MHz]   
					if (softtrigger)
					{
						adc_tuner0 = Evaluate_ADC(tuner); // read the ADC_value 
						delay_ms(measuringtime); // wait 
						TransmitADC(adc_tuner0); 
					}                 
					sweepcount++;
				} while (sweepcount < sweeplength);
				if (format==4)  
					printf(carriage_return); // Send carriage return  
				if (debug)
					printf("$CRX:P2=Stop single sweep\r"); // Test message
				break;
			}
			default:  error = true; break; // illegal command
		}
	}   
	else
	if (u=='+')  // P3 increment in 62.5kHz steps
	{                 
		if (debug)
			printf("$CRX:Single step +62.5kHz\r"); // Test message
		frequency = frequency + synthesizer_resolution; 
		SetTuner(frequency);  		// old tuner-address, frequency[MHz]    
		if (softtrigger)
		{
			adc_value = Evaluate_ADC(tuner); // read the ADC_value 
			TransmitADC(adc_value);    
		}                 
		sweepcount++;
		if (sweepcount > sweeplength) 
			sweepcount = 0;
	}
	else	
	if (u=='-')  // P4 decrement in 62.5kHz steps
	{                 
		if (debug)
			printf("$CRX:Single step -62.5kHz\r"); // Test message
		frequency = frequency - synthesizer_resolution; 
		SetTuner(frequency);  		// old tuner-address, frequency[MHz]    
		if (softtrigger)
		{
			adc_value = Evaluate_ADC(tuner); // read the ADC_value 
			TransmitADC(adc_value);    		
		}                 
		sweepcount--;
		if (sweepcount<1) 
			sweepcount = sweeplength;
	}	
	else
	if (u=='R')  // Read Port(s)
	{  
		switch (v) // Evaluate parameter A...D
		{
			case 17: p=PORTA;   break; // A
			case 18: p=PINB;   break; // B
			case 19: p=PORTC;   break; // C
			case 20: p=PIND;    break; // D    
			//printf("PORTB.%u=%u\r",0,PINB.0);

			default: error = true; break; // illegal command
		}
		sprintf(temp,"PORT%c=%u",cmd[1],p);
		printf("$CRX:%s\r",temp); // send result to host
	} 
	else 
	if (u=='S')  // Set Port
	{  
		switch (v) // Evaluate first parameter 
		{
			case 0: // S0 stop state machine
			{  	
				StopTimer(); 	// disable the interrupt service routine (state machine)
				printf("$CRX:Stopped\r"); // state machine started
				chip_select = 1;      // chip select high   
			        WDTCR = 0x1C;         // disable the watchdog timer
			        WDTCR = 0x17;
				if (debug)   
				{
					printf("$CRX:Sweeplength%u\r",sweeplength); // send number of choosen frequencies to host to check   				
					printf("$CRX:Stop state machine\r");   
				}	
				break;				
			} 
			case 1:  // start state machine
			{			
				chip_select = 0;     // chip select low used for the external EEPROM
				spi(0x03);	// Command: read EEPROM
				spi(0x00);	// Address high byte
    				spi(0x00);	// Address low byte   
     		     		counter      = 0;      // Init counter variable 
     		     		stepcount    = 0;      // Init the intgration counter
     		    		number_count = 0;      // reset the number of counts         		 	 
     		    		set_once = true;
     		    		transferdata = true; // reset and enable the datatransfer between host and mainboard\
     		    		stoptransfer = false;    // disable the datatransfer   (state machine)
     		     	 	send_once    = true;         
     		    		not_send     = false;  
     		    		eot_flag     = false; 		// don't send the eot character at start
     		     		WDTCR |= (1<<WDE);   	// Write logical one to WDE watchdog enable flag
     				if (debug)
     			 		printf("$CRX:Start state machine\r");
     				printf("$CRX:Started\r"); // state machine started 
     				printf("%u",2);   // start of transmission  
     				StartTimer();  // enable the interrupt service routine			
     				break;
			}  
			//case 17: // Port A forbidden
			case 18: // Port B
			{     
				switch (w) // select bit in SBb
				{
					case 0: PORTB.0=1; break;
					case 1: PORTB.1=1; break;
					case 2: PORTB.2=1; break;
					case 3: PORTB.3=1; break;
					case 4: PORTB.4=1; break;
					case 5: PORTB.5=1; break;
					case 6: PORTB.6=1; break;
					case 7: PORTB.7=1; break;
					default: error=true; break; // illegal command
				}
				break; 
			}
			case 19: // Port C
			{     
				switch (w) // select bit in SCb
				{
					case 0: PORTC.0=1; break;
					case 1: PORTC.1=1; break;
					case 2: PORTC.2=1; break;
					case 3: PORTC.3=1; break;
					case 4: PORTC.4=1; break;
					case 5: PORTC.5=1; break;
					case 6: PORTC.6=1; break;
					case 7: PORTC.7=1; break;
					default: error=true; break; // illegal command
				}
				break; 
			}
			case 20: // Port D
			{     
				switch (w) // select bit in SDb
				{
					case 0: PORTD.0=1; break;
					case 1: PORTD.1=1; break;
					case 2: PORTD.2=1; break;
					case 3: PORTD.3=1; break;
					case 4: PORTD.4=1; break;
					case 5: PORTD.5=1; break;
					case 6: PORTD.6=1; break;
					case 7: PORTD.7=1; break;
					default: error=true; break; // illegal command
				}
				break; 
			} 
			default: error = true; break; // illegal command
		}
	} 
	else 
	if (u=='T')  // Trigger mode
	{          
		softtrigger   = false;
		timertrigger  = false;
		externtrigger = false;
		switch (v) // Evaluate parameter 0..2
		{
			case 0: // T0=trigger via software
			{
				softtrigger = true; 
				break;     
			}
			case 1: // T1=trigger via ATmega16 crystal 11.0592MHz
			{
				InitTimerSynClock(prescaler_value_Syn);  //internal syn. clock 11.0592MHz
				if (debug)
    					printf("$CRX:internal clock\r");	
				timertrigger = true; 
				break; 
			}
			case 2: // T2=trigger via external clock
			{				
				InitTimerAsynClock(prescaler_value_Asyn); //external asyn. clock 1MHz Timer/counter1 is used
				if (debug)
    					printf("$CRX:external clock\r");
				externtrigger = true; 
				break;    
			}
			default: error = true; break; // illegal command
		} 
	} 
	else   
	if (u=='U')  // Read system voltages
	{                 
 		adc_value = Evaluate_ADC(v);
 		uin = (float)adc_value*adc_reference/adc_resolution; // get voltage  
		switch (v) // Evaluate parameter
		{
			case 2: // receiver gain control voltage 
			{
				rht = 2.0*uin/adc_scaling;
				printf("$CRX:AGC gain = %u.%02uV\r",(int)(rht),(int)(100.0*(rht-(int)(rht)) ));
				break; 

			}
			case 3: // GND
			{
				break; 
			}         
			case 4: // GND
			{                                                 
                               	rht = uin/adc_scaling;
				printf("$CRX:Emitter BF199 = %u.%02uV\r",(int)(rht),(int)(100.0*(rht-(int)(rht)) ));
				break; 
			}
			case 5: // GND
			{                                              
				break; 	
			}  	
			case 6: // � input voltage (+12V)
			{                                              
				rht = uin/(adc_scaling)*6.6;
				printf("$CRX:Analog Input = %u.%02u%V\r",(int)(rht),(int)(100.0*(rht-(int)(rht)) ));
				break;  	
			}	
			case 7: // GND
			{                                              
				break; 
			}
			default: error = true;  break; // illegal command
		}
	} 
	else
	if (u=='%')  // Transmision format (for tests only)
	{          
		switch (v) // Evaluate parameter 0..2
		{
			case 0: format=0; break; 		// decimal 10bit
			case 1: format=1; break; 		// decimal 8bit
			case 2: format=2; break; 		// Millivolt
			case 3: format=3; break; 		// HEX TransmitString()
			case 4: format=4; break; 		// HEX SendString()
			case 5: format=5; break; 		// frequency+decimal Millivolt
			default: error = true;  break; 	// illegal command
		} 
		if (debug)
			printf("$CRX:TransmissionFormat=%u\r",format); // Test message
	} 
	else 
	if (u=='?')  // Read system infos
	{                 			
  		printf("$CRX:%s\r",version);  // Start message (version)  
  				 	
		if (debug)
			printf("$CRX:Debug=On\r");
		else
			printf("$CRX:Debug=Off\r");
	
		if (softtrigger)
			printf("$CRX:Trigger=Soft\r");
		else
		if (timertrigger)
			printf("$CRX:Trigger=Intern\r");
		else
		if (externtrigger)
			printf("$CRX:Trigger=Extern\r");
		else
			printf("$CRX:Trigger=No\r"); 
		
		printf("$CRX:FPUcodex=%u\r",FPUcodex);    
		printf("$CRX:GS =%u\r",prescaler_value_Syn);  
		printf("$CRX:GA =%u\r",prescaler_value_Asyn);  
		
		printf("$CRX:Delay=%umsec\r",measuringtime); // soft-delay
													
		f_MHz = (Word)frequency;
		printf("$CRX:Frequency=%u.%uMHz\r",f_MHz,(Word)((frequency-f_MHz)*1000+0.5)); // MHz
		
		printf("$CRX:Sweeplength=%u\r",sweeplength); // pixel    
		
		low_band_max = EEPROM_read(115); // TL low_band_max value
		printf("$CRX:low_band_max=%uMHz\r",low_band_max); // pixel
		
		mid_band_max = EEPROM_read(120); // TM mid_band_max value
		printf("$CRX:mid_band_max=%uMHz\r",mid_band_max); // pixel
		
		high_band_max = EEPROM_read(125); // TH high_band_max value
		printf("$CRX:high_band_max=%uMHz\r",high_band_max); // pixel
		
		//printf("$CRX:Idle=%ux\r",idlecount);
		printf("$CRX:Idle=0\r");
	} 
	else  
	if (u=='\0')  // ENTER pressed by the host/user
	{  
		// nothing to do
	}
	else
		error = true; 
	
	// check error state 	
	if (error) 
	{
		printf("$CRX:illegal command!\r"); // unknown command, no further action
		error = false; // Reset error flag
	}
}
//-------------------------------------------------------------------------------------

	
	           
/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: timer.c                                                */
/*                                                                       */
/*  Revision: V1.0     Date: 10.03.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: main function for the timer interrupt (state machine)       */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 27.01.2003  
// Updated by: Hansueli Meyer 21.03.2003 external EEPROM via SPI built in
// Updated by: Hansueli Meyer 27.03.2003 start and stop functions timer
// Updated by: Hansueli Meyer 21.04.2003 state machine implemented
// Updated by: Hansueli Meyer 15.06.2003 state machine parallel and alternating measireing mode
// Updated by: Hansueli Meyer 21.07.2003 integration mode of data    
// Updated by: Hansueli Meyer 12.06.2003 watchdog timer implemented   
// Updated by: Hansueli Meyer 20.09.2003 different FPU codes implemented
// Updated by: Hansueli Meyer 10.10.2003 PMM and AMM removed, new file for differnt observation modes O0-O8
// Updated by: Hansueli Meyer 02.01.2004 the tunercode is now storaged in the EEPROM (not the frequency)
// Updated by: Chr. Monstein  21.09.2010 Anpassungen an 10Bit HAM

//-------------------------------------------------------------------------------------      

//include files
#include <delay.h>  
#include <math.h>     
#include <spi.h>     
#include <stdio.h>
#include <mega16.h>
#include <stdlib.h>     
#include <ctype.h>

#include "callisto.h"    
#include "rs232.h" 
#include "command.h"
#include "digital_io.h"  
#include "tuner.h" 
#include "adc.h"
#include "timer.h"
#include "spieeprom.h" 
#include "setfopa.h"    

extern bit transferdata;      // import from callisto.c 
extern bit stoptransfer;      // import from callisto.c   	
extern bit eot_flag;          // import from callisto.c    
extern bit send_result;       // import from callisto.c 

extern Byte set_once;
extern Byte send_once;  
extern Byte not_send;   
extern Word result;           // state machine tuner value  

extern Byte FPUcodex;         // FPU codes for tuner0 or tuner1 

extern Word number_count;     // import from callisto.c 
extern Word counter;          // count the measured frequencies used in command.c (GH)   
extern Word sweeplength;      // import from command.c  
extern Word stepcount;        // import from command.c  
extern Word adc_value;	      // import from adc.c 
extern bit reset_flag;	      // import from callisto.c   

extern float frequency;       // imported from callisto.c	

//------------------------------------------------------------------------------------
void InitTimerSynClock(Word prescaler_value_Syn) //internal clock 11.0592MHz Timer/counter1 is used
{
	TCCR1B=0x0B; 		// set Timer1 and prescaler_value (prescaler 0x0A=8;0x0B=64;0x0C=256)
	OCR1A=prescaler_value_Syn;  // scaler value for synchrounos mode
} 
//------------------------------------------------------------------------------------
void InitTimerAsynClock(Word prescaler_value_Asy) //external clock 1MHz Timer/counter1 is used
{
	TCCR1B=0x0F; 		// Timer1 working as a counter (no prescaler)  
	OCR1A=prescaler_value_Asy; // scaler value for asynchrounos mode
	DDRB=0xBC; 			// Set PB1 and PB0 as an Input 
}    
//------------------------------------------------------------------------------------
void StartTimer(void)  		// Start counter synchrounos internal clocking 11.0592MHz
{
	TIFR=enable_interrupt;	// enable Output Compare Flag 1A
	TIMSK=enable_interrupt;	// Timer/Counter1 Output Compare A Match Interrupt Enable    
}
//------------------------------------------------------------------------------------
void StopTimer(void)  		// Stop counter synchrounos internal clocking 11.0592MHz
{
	TIFR=disable_interrupt; // disable Output Compare Flag 1A
	TIMSK=disable_interrupt;// Timer/Counter1 Output Compare A Match Interrupt Disable    
} 
//------------------------------------------------------------------------------------
interrupt [TIM1_COMPA] void timer1_compa_isr(void) //interrupt for the main loop PMM
{           	
      static Byte state1=0; 
      static Byte db1,db2,cb,bb; 
      Byte dummy1,dummy2,dummy3,dummy4;  
      static Byte no_data;  
              
      counter=(counter)%(sweeplength);
      
          if (transferdata && (counter==0))   // disable the data transmission but finish the sweewplength
	  {  
 			stoptransfer=false; 
  			if ((eot_flag) && (send_once)) 
  			{ 
  				printf("23232323");
  				printf("&");    // end of transmission 
  				send_once=false;      
  	   		}  			
  	  }         	
  	  if ((!transferdata) && (counter==0))  // enable the data transmission but finish the sweeplength
 	  {  
  	    	stoptransfer=true; 
  	    	not_send=true;  
  			if (set_once) 
  			{
  				no_data=0; 
  				set_once=false;			
  			}
  	  }  
         
          switch (state1)
   	  {
 		case 0:    // functions need about 260us
 		{ 						 		      
 					       
 			// set tuner 0 		      
                     // Output sequence to device via digital-I/O-Port, send start bit first
                    I2C_Start();
                    
                    I2C_Wrbyte(192); // Send address byte
                    I2C_Wrbyte(db1); // Send divider byte 1
                    I2C_Wrbyte(db2); // Send divider byte 2
                    I2C_Wrbyte(cb);  // Send control byte
                    I2C_Wrbyte(bb);  // Send band-switch byte
                    
                    // Send stopp bit
                    I2C_Stop();
                      	         	    			   					
 			//result = ADCW>>2; // read ADC 8bit should be enough value   
 			result = ADCW; // read ADC 10bit which is better...
 			SetFPU((Byte)FPUcodex); // set FPU, normally left first   1us   		
  			state1++;
  			break;
  		}		 		
        	case 1:  // functions need about 260us
        	{      		  	  		  
            		if (counter==0)
            		{
                		chip_select=1;  // chip select high	   
                		chip_select=0;  // chip select low
                		spi(0x03);      // Command: read EEPROM
                		spi(0x00);	// Address high byte=0 because start at address=0
                    		spi(0x00);      // Address low byte=0 because start at address=0                   
             		}  
			db1=spi(0); 
			db2=spi(0);
			cb=spi(0);
			bb=spi(0);  
		        dummy1=spi(0);
		 	dummy2=spi(0);
		    	dummy3=spi(0);
		    	dummy4=spi(0);   		  		
  		  	
            		if ((stoptransfer) && (no_data==2))     
            		{
             		 	send_result=true; 
             		 	no_data=1;    		 		  
            		}  
            		if (not_send)       
                	no_data++;  
                	  		    	  	    	     	 		  	 
  	  		state1=0;
  	  		counter++;
  	  		TriggerADC(0); 				
  	  		break;		 	
  	 	} 
  	 	default: break; // other states not foreseen     	 		  
  	 } // end of state machine     
       
	//reset the watchdog timer/ if not, the ATmega16 is being reseted
 	if (reset_flag)
  		#asm("wdr")	
}
//------------------------------------------------------------------------------------
void Init_Watchdog(void)
{ 
     WDTCR=0x07;          // init Watchdog Timer prescaling (wait 256ms)
}
//------------------------------------------------------------------------------------
 
 
 
 
 
 
 
 
 
 
 
 
/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: spieeprom.c                                            */
/*                                                                       */
/*  Revision: V1.0     Date: 27.01.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: external EEPROM read and write functions via SPI Bus        */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 27.01.2003  
// Updated by: Hansueli Meyer 04.02.2003  reading and writing 8byte
// Updated by: Hansueli Meyer 30.03.2003  Timer and EEPROM in the same program
// Updated by: Hansueli Meyer 02.04.2003  new function EEPROM reading sequential 
// Updated by: Hansueli Meyer 15.04.2003  modus 0-255 stored in the EEPROM  
// Updated by: Hansueli Meyer 14.10.2003  acknowledge for software handshaking 
//-------------------------------------------------------------------------------------      

//include files
#include <delay.h>       
#include <spi.h>     
#include <stdio.h>
#include <mega16.h>
#include <stdlib.h>
 
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"   

extern Word sweeplength;  // import from callisto.c
extern Word number_count; // import from callisto.c

//------------------------------------------------------------------------------------

void eeprom_read_float(Word address,Byte *db1,Byte *db2,Byte *cb,Byte *bb) //Read 8 byte from external EEPROM
{
	chip_select=0;          // chip select low activate EEPROM
	spi(0x03);			// Command read EEPROM
	spi(address / 256);	// Address high byte
	spi(address % 256);	// Address low byte
	
	*db1=spi(0); 
	*db2=spi(0);
	*cb=spi(0);
	*bb=spi(0);
   		  	
	chip_select=1;          // chip select high stop reading mode    
}    

//-------------------------------------------------------------------------------------
void eeprom_write_string(Word address, Byte db1,Byte db2, Byte cb,Byte bb) // Write 8 byte to external EEPROM
{								   	  
	chip_select=0; // chip select low
	spi(0x06);     // write enable byte
	chip_select=1; // chip select high
	chip_select=0; // chip select low
        spi(0x02);     // command write EEPROM   
	spi(address / 256); // Address high byte
	spi(address % 256); // Address low byte
	spi(db1);
	spi(db2);
	spi(cb);
	spi(bb);
	spi(0x00);
	spi(0x00);
	spi(0x00);
	spi(0x00);	
	
	chip_select=1; // chip select high stop writing mode
	delay_ms(6); // 6ms delay to finishing the write cycle
	printf("]"); // acknowledge for software handshaking between mainboard and host	
}
//-------------------------------------------------------------------------------------            







/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: inteeprom.c                                            */
/*                                                                       */
/*  Revision: V1.0     Date: 22.04.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: internal EEPROM read and write cycle			       */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 22.04.2003  
// Updated by: 
//-------------------------------------------------------------------------------------      

//include files
#include <delay.h>       
#include <spi.h>     
#include <stdio.h>
#include <mega16.h>
#include <stdlib.h> 
#include <math.h> 
 
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"

//-------------------------------------------------------------------------------------      
void EEPROM_write(Word uiAddress, char *datastring) // write 5 byte to the internal EEPROM
{
	Byte i;    
	for (i = 0; i <= 4; i++)
	{ 
		
		while(EECR & (1<<EEWE)) // Wait for completion of previous write
			;
		EEAR = uiAddress+i;     // Set up address and data registers
		EEDR = datastring[i];
		EECR |= (1<<EEMWE);    	// Write logical one to EEMWE
		EECR |= (1<<EEWE);      // Start eeprom write by setting EEWE 
	}            
}
//------------------------------------------------------------------------------------- 
float EEPROM_read(Word uiAddress)   // read 5 byte from the internal EEPROM
{
	Byte x;
	char datastring[6];
	for(x = 0; x <= 4; x++)     
		{

			while(EECR & (1<<EEWE)) // Wait for completion of previous write
				;
			EEAR = uiAddress+x; // Set up address register 
			EECR |= (1<<EERE);  // Start eeprom read by writing EERE 
			datastring[x] = EEDR; // Return data from data register 			 
		}                         	
	datastring[5]='\0';            
	return atof(datastring);       
}
//------------------------------------------------------------------------------------- 




                                    
/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: setfopa.c                                              */
/*                                                                       */
/*  Revision: V1.4     Date: 04.06.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: setting the FPU parallel output port using Focuscode        */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 04.06.2003 set FPU function implemented
// Updated by: Hansueli Meyer 05.08.2003 prepare function left and right measurement
// Updated by: Hansueli Meyer 20.09.2003 prepare function removed

//-------------------------------------------------------------------------------------
// Include files
#include <stdio.h>   
#include <string.h> 
#include <stdlib.h>
#include <delay.h>
#include <spi.h>
#include <mega16.h>   

#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h" 

//-------------------------------------------------------------------------------------
void SetFPU(Byte FOPAcode) // the right FOPA code is send to the focal plane unit
{
   	PORTC=FOPAcode;
}
//-------------------------------------------------------------------------------------






















	           
