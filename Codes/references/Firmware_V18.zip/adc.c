/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: adc.c                                                  */
/*                                                                       */
/*  Revision: V1.0     Date: 30.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: AnalogToDigital-Converter Radiospectrometer CALLISTO        */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 30.11.2002
// Updated by: Chr. Monstein 09.12.2002 ADC-format changed form ASCII mV to HEX &
// -ADC samples 32 times faster
// Updated by: Chr. Monstein 15.12.2002 serial output via printf() instead of TransmitString()
// Updated by: Chr. Monstein 28.12.2002 adc transmission with 4 different formats
// Updated by: Chr. Monstein 30.12.2002 test adc transmission without terminator [SendString()]
// Updated by: Chr. Monstein 03.04.2003 changed from AT90S5835 to ATmega16    
// Updated by: Meyer Hansueli 05.05.2003 new function implemented READ_ADC   
// Updated by: Meyer Hansueli 07.10.2003 new function Evaluate_ADC
// Updated by: Chr. Monstein: 21.09.2010 // Anpassungen an 10Bit HAM

//-------------------------------------------------------------------------------------
#include <mega16.h>
#include <stdio.h> 
#include <stdlib.h>

#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"  

//-------------------------------------------------------------------------------------
// global data (import/export)
bit adc_ready = false;
Word adc_value; 

extern bit adc_command; // import from callisto.c
extern Byte format;     // import from command.c
extern float frequency; // import from command.c      
extern float uin;       // import from command.c
extern float rht;       // import from command.c

//-------------------------------------------------------------------------------------
void TransmitADC(Word value) 							// Send ADC value to the host (debugging tool)
{
	char temp[12] = ""; 
	Word f_MHz;     							// temporary frequency  
  	float u;                                                
	switch(format) 								// attention: different transmission versions used [TransmitString()/printf())]
	{
		case 0: 								// decimal 10bit
		{
			printf("$CRX:%u\r",value); 
			break;
		}
		case 1: 								// decimal 8bit
		{
			printf("$CRX:%u\r",value/4); 
			break;
		}
		case 2: 								// decimal Millivolt
		{
  			u = (float)value*2500/1024;
  			sprintf(temp,"ADC%u=%umV",ADMUX,(Word)u); // mV
			printf("$CRX:%s\r",temp);
			break;
		}
		case 3: // HEX 8 bit
		{
			sprintf(temp,"%02X",value/4); 	// digit [hex]
			printf("$CRX:%s\r",temp);
			break;
		}     
		case 4: // HEX 8 bit
		{
			sprintf(temp,"%02X",value/4); 	// digit [hex] 8 bit no carriage return and no $CRX:
			printf("%s",temp); 
			break;
		}           
		case 5: 						// frequency+decimal Millivolt
		{
  			u = ((float)value)*2500.0/1024.0; 
			f_MHz = (Word)frequency;
			sprintf(temp,"%03u.%03u,%u",f_MHz,(Word)((frequency-f_MHz)*1000.0+0.5),(Word)u); // MHz
			printf("$CRX:%s\r",temp);
			break;
		} 
	}
	adc_command = false; 						// prevent another transmission    
}    
//-------------------------------------------------------------------------------------
void InitADC(void) 		// ADC initialization, Clock frequency: xyz kHz, Interrupts: On
{
	ADMUX  = ADC_VREF_TYPE;
       	ADCSRA = 0x8E;            // 0x8E=173kHz;0x8C=346kHz clock frequency (11.0952MHz/16)   
	SFIOR &= 0xEF;            // enable high speed mode ADC
	SFIOR |= 0x10;  
}
//-------------------------------------------------------------------------------------
Word Evaluate_ADC(Byte trigger_number)  
{
	TriggerADC(trigger_number);
    	do	
    	{ 
	} while (!adc_ready); // wait until adc converting has finished
	adc_value = ADCW;   
        return adc_value;
}
//-------------------------------------------------------------------------------------
void TriggerADC(Byte channel)
{
	adc_ready = false;   		// to syncronize read process of ADC 
	ADMUX = channel;     		// Select ADC input 0  or ADC input 1
	ADCSRA |= 0x40;     		// Start AD conversion
}
//-------------------------------------------------------------------------------------
interrupt [ADC_INT] void adc_isr(void) // ADC interrupt service routine
{       
	adc_ready = true; 
}
//-------------------------------------------------------------------------------------






















