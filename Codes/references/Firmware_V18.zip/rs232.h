/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: rs232.h                                                */
/*                                                                       */
/*  Revision: V1.0     Date: 30.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Prototype definitions for source c-files                    */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 15.11.2002  Idea taken from AVR306
// Updated by: Chr. Monstein 02.12.2002  unit name changed
// Updated by: Chr. Monstein 27.12.2002  line_feed introduced
// Updated by: Chr. Monstein 30.12.2002  SendString() without terminator
// Updated by: Hansueli Meyer 09.04.2003 changed from At90S8535 to ATmega16 
// Updated by: Hansueli Meyer 26.01.2004 rx and tx buffer size changed from 64 to 72
//-------------------------------------------------------------------------------------
#ifndef rs232.h
#define rs232.h

#define RXB8 1
#define TXB8 0
#define UPE 2
#define OVR 3
#define FE 4
#define UDRE 5
#define RXC 7

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<OVR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
#define RX_COMPLETE (1<<RXC)    

#define carriage_return 13    

#define RX_BUFFER_SIZE 72
#define TX_BUFFER_SIZE 72     

#define baudrate 5 	//set baudrate to 115200 using a 11.0592MHz crystal 
//#define baudrate 11 	//set baudrate to 56800 using a 11.0592MHz crystal
//#define baudrate 17 	//set baudrate to 38400 using a 11.0592MHz crystal

char getchar(void);  	// Get a character from the USART Receiver buffer                  
void putchar(char c); 	// Write a character to the USART Transmitter buffer
void InitUSART(void); 	//Init the RS232 Communication                  
interrupt [USART_RXC] void uart_rx_isr(void);// USART Receiver interrupt service routine
interrupt [USART_TXC] void uart_tx_isr(void);// USART Transmitter interrupt service routin

#endif
//-------------------------------------------------------------------------------------


