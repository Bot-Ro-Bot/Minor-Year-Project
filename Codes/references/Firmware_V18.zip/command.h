/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: command.h                                              */
/*                                                                       */
/*  Revision: V1.0     Date: 02.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Prototype definitions for source c-files                    */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 27.12.2002 moved from rs232.h into separate file
// Updated by: Hansueli Meyer 03.04.2003 new addresses defined for the internal EEPROM 
// Updated by: Hansueli Meyer 03.04.2003 integration and sweeplength address removed
//-------------------------------------------------------------------------------------

#ifndef command.h
#define command.h   

#define PB0 2

#define address_Syn 105                // start address of the internal EEPROM byte
#define address_Asyn 110               // start address of the internal EEPROM byte
#define address_lowband 115            // start address of the internal EEPROM byte
#define address_midband 120            // start address of the internal EEPROM byte
#define address_highband 125           // start address of the internal EEPROM byte    
#define adc_resolution 1024.0
#define adc_reference 2500.0
#define adc_scaling 1000.0
void CommandInterpreter(char *cmd);	   // main function to read commands and communicate with host

#endif

//-------------------------------------------------------------------------------------

