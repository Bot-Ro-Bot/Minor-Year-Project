/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: timer.c                                                */
/*                                                                       */
/*  Revision: V1.0     Date: 10.03.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: main function for the timer interrupt (state machine)       */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 27.01.2003  
// Updated by: Hansueli Meyer 21.03.2003 external EEPROM via SPI built in
// Updated by: Hansueli Meyer 27.03.2003 start and stop functions timer
// Updated by: Hansueli Meyer 21.04.2003 state machine implemented
// Updated by: Hansueli Meyer 15.06.2003 state machine parallel and alternating measireing mode
// Updated by: Hansueli Meyer 21.07.2003 integration mode of data    
// Updated by: Hansueli Meyer 12.06.2003 watchdog timer implemented   
// Updated by: Hansueli Meyer 20.09.2003 different FPU codes implemented
// Updated by: Hansueli Meyer 10.10.2003 PMM and AMM removed, new file for differnt observation modes O0-O8
// Updated by: Hansueli Meyer 02.01.2004 the tunercode is now storaged in the EEPROM (not the frequency)
// Updated by: Chr. Monstein  21.09.2010 Anpassungen an 10Bit HAM

//-------------------------------------------------------------------------------------      

//include files
#include <delay.h>  
#include <math.h>     
#include <spi.h>     
#include <stdio.h>
#include <mega16.h>
#include <stdlib.h>     
#include <ctype.h>

#include "callisto.h"    
#include "rs232.h" 
#include "command.h"
#include "digital_io.h"  
#include "tuner.h" 
#include "adc.h"
#include "timer.h"
#include "spieeprom.h" 
#include "setfopa.h"    

extern bit transferdata;      // import from callisto.c 
extern bit stoptransfer;      // import from callisto.c   	
extern bit eot_flag;          // import from callisto.c    
extern bit send_result;       // import from callisto.c 

extern Byte set_once;
extern Byte send_once;  
extern Byte not_send;   
extern Word result;           // state machine tuner value  

extern Byte FPUcodex;         // FPU codes for tuner0 or tuner1 

extern Word number_count;     // import from callisto.c 
extern Word counter;          // count the measured frequencies used in command.c (GH)   
extern Word sweeplength;      // import from command.c  
extern Word stepcount;        // import from command.c  
extern Word adc_value;	      // import from adc.c 
extern bit reset_flag;	      // import from callisto.c   

extern float frequency;       // imported from callisto.c	

//------------------------------------------------------------------------------------
void InitTimerSynClock(Word prescaler_value_Syn) //internal clock 11.0592MHz Timer/counter1 is used
{
	TCCR1B=0x0B; 		// set Timer1 and prescaler_value (prescaler 0x0A=8;0x0B=64;0x0C=256)
	OCR1A=prescaler_value_Syn;  // scaler value for synchrounos mode
} 
//------------------------------------------------------------------------------------
void InitTimerAsynClock(Word prescaler_value_Asy) //external clock 1MHz Timer/counter1 is used
{
	TCCR1B=0x0F; 		// Timer1 working as a counter (no prescaler)  
	OCR1A=prescaler_value_Asy; // scaler value for asynchrounos mode
	DDRB=0xBC; 			// Set PB1 and PB0 as an Input 
}    
//------------------------------------------------------------------------------------
void StartTimer(void)  		// Start counter synchrounos internal clocking 11.0592MHz
{
	TIFR=enable_interrupt;	// enable Output Compare Flag 1A
	TIMSK=enable_interrupt;	// Timer/Counter1 Output Compare A Match Interrupt Enable    
}
//------------------------------------------------------------------------------------
void StopTimer(void)  		// Stop counter synchrounos internal clocking 11.0592MHz
{
	TIFR=disable_interrupt; // disable Output Compare Flag 1A
	TIMSK=disable_interrupt;// Timer/Counter1 Output Compare A Match Interrupt Disable    
} 
//------------------------------------------------------------------------------------
interrupt [TIM1_COMPA] void timer1_compa_isr(void) //interrupt for the main loop PMM
{           	
      static Byte state1=0; 
      static Byte db1,db2,cb,bb; 
      Byte dummy1,dummy2,dummy3,dummy4;  
      static Byte no_data;  
              
      counter=(counter)%(sweeplength);
      
          if (transferdata && (counter==0))   // disable the data transmission but finish the sweewplength
	  {  
 			stoptransfer=false; 
  			if ((eot_flag) && (send_once)) 
  			{ 
  				printf("23232323");
  				printf("&");    // end of transmission 
  				send_once=false;      
  	   		}  			
  	  }         	
  	  if ((!transferdata) && (counter==0))  // enable the data transmission but finish the sweeplength
 	  {  
  	    	stoptransfer=true; 
  	    	not_send=true;  
  			if (set_once) 
  			{
  				no_data=0; 
  				set_once=false;			
  			}
  	  }  
         
          switch (state1)
   	  {
 		case 0:    // functions need about 260us
 		{ 						 		      
 					       
 			// set tuner 0 		      
                     // Output sequence to device via digital-I/O-Port, send start bit first
                    I2C_Start();
                    
                    I2C_Wrbyte(192); // Send address byte
                    I2C_Wrbyte(db1); // Send divider byte 1
                    I2C_Wrbyte(db2); // Send divider byte 2
                    I2C_Wrbyte(cb);  // Send control byte
                    I2C_Wrbyte(bb);  // Send band-switch byte
                    
                    // Send stopp bit
                    I2C_Stop();
                      	         	    			   					
 			//result = ADCW>>2; // read ADC 8bit should be enough value   
 			result = ADCW; // read ADC 10bit which is better...
 			SetFPU((Byte)FPUcodex); // set FPU, normally left first   1us   		
  			state1++;
  			break;
  		}		 		
        	case 1:  // functions need about 260us
        	{      		  	  		  
            		if (counter==0)
            		{
                		chip_select=1;  // chip select high	   
                		chip_select=0;  // chip select low
                		spi(0x03);      // Command: read EEPROM
                		spi(0x00);	// Address high byte=0 because start at address=0
                    		spi(0x00);      // Address low byte=0 because start at address=0                   
             		}  
			db1=spi(0); 
			db2=spi(0);
			cb=spi(0);
			bb=spi(0);  
		        dummy1=spi(0);
		 	dummy2=spi(0);
		    	dummy3=spi(0);
		    	dummy4=spi(0);   		  		
  		  	
            		if ((stoptransfer) && (no_data==2))     
            		{
             		 	send_result=true; 
             		 	no_data=1;    		 		  
            		}  
            		if (not_send)       
                	no_data++;  
                	  		    	  	    	     	 		  	 
  	  		state1=0;
  	  		counter++;
  	  		TriggerADC(0); 				
  	  		break;		 	
  	 	} 
  	 	default: break; // other states not foreseen     	 		  
  	 } // end of state machine     
       
	//reset the watchdog timer/ if not, the ATmega16 is being reseted
 	if (reset_flag)
  		#asm("wdr")	
}
//------------------------------------------------------------------------------------
void Init_Watchdog(void)
{ 
     WDTCR=0x07;          // init Watchdog Timer prescaling (wait 256ms)
}
//------------------------------------------------------------------------------------
 
 
 
 
 
 
 
 
 
 
 
 