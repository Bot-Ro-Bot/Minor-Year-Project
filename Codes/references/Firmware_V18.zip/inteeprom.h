/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: inteeprom.h                                            */
/*                                                                       */
/*  Revision: V1.0     Date: 22.04.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: internal EEPROM read and write header file		       */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 22.04.2003  
// Updated by: 
//-------------------------------------------------------------------------------------      

#ifndef inteeprom.h
#define inteeprom.h 

#define EEWE 1           // EEPROM write enable
#define EEMWE 2          // EEPROM Master Write Enable
#define EERE 0           // EEPROM read enable

void EEPROM_write(Word uiAddress, char *datastring); 	//internal EEPROM writing
float EEPROM_read(Word uiAddress); 				//internal EEPROM reading

#endif

//-------------------------------------------------------------------------------------