/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: setfopa.c                                              */
/*                                                                       */
/*  Revision: V1.4     Date: 04.06.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: setting the FPU parallel output port using Focuscode        */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 04.06.2003 set FPU function implemented
// Updated by: Hansueli Meyer 05.08.2003 prepare function left and right measurement
// Updated by: Hansueli Meyer 20.09.2003 prepare function removed

//-------------------------------------------------------------------------------------
// Include files
#include <stdio.h>   
#include <string.h> 
#include <stdlib.h>
#include <delay.h>
#include <spi.h>
#include <mega16.h>   

#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h" 

//-------------------------------------------------------------------------------------
void SetFPU(Byte FOPAcode) // the right FOPA code is send to the focal plane unit
{
   	PORTC=FOPAcode;
}
//-------------------------------------------------------------------------------------






















	           