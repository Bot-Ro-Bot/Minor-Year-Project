/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: setfopa.h                                              */
/*                                                                       */
/*  Revision: V1.0     Date: 08.05.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: Prototype definitions for source c-files                    */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 08.05.2003
// Updated by: Hansueli Meyer 20.09.2003 prepare function removed

/*-----------------------------------------------------------------------*/

#ifndef setfopa.h
#define setfopa.h

void SetFPU(Byte FOPAcode);	// send FOPA code to FOPA controller board via parallel output

#endif

//-------------------------------------------------------------------------------------