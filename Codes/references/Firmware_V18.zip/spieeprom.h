/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: spieeprom.h                                            */
/*                                                                       */
/*  Revision: V1.0     Date: 27.01.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: Prototype definitions for source c-files                    */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 27.01.2003  
// Updated by:

//-------------------------------------------------------------------------------------

/*Prototypes for SPI access functions */  
#ifndef _SPIeeprom_INCLUDED_
#define _SPIeeprom_INCLUDED_ 
#define chip_select PORTB.4     
//-------------------------------------------------------------------------------------

#pragma used+              					
void eeprom_write_string(Word address, Byte db1,Byte db2, Byte cb,Byte bb); // Write 8 byte to external EEPROM
void eeprom_read_float(Word address,Byte *db1,Byte *db2,Byte *cb,Byte *bb); // Read 8 byte from the EEPROM (8byte -> float value)
//void eeprom_read_sequent(Byte *db1,Byte *db2,Byte *cb,Byte *bb); // read sequently from the external EEPROM									//Read 8 byte sequential from external EEPROM
Byte spi(Byte data);  // send one data byte via the SPI bus														//send and receive data function             
#pragma used-

#endif

