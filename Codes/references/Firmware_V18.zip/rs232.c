/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: rs232.c                                                */
/*                                                                       */
/*  Revision: V1.4     Date: 30.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Receives and Transmits data via Interrupt on UART ATmega16  */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 15.11.2002  Idea taken from AVR306
// Updated by: Chr. Monstein 02.12.2002  commands M, T introduced, unit name changed
// Updated by: Chr. Monstein 10.12.2002  commands L introduced, Px changed
// Updated by: Chr. Monstein 15.12.2002  status command optimized
// Updated by: Chr. Monstein 16.12.2002  commands CPb and SPb included
// Updated by: Chr. Monstein 27.12.2002  command interpreter moved to command.c
// Updated by: Chr. Monstein 30.12.2002  new function SendString() [no terminator]
// Updated by: Hansueli Meyer 09.04.2003 changed from At90S8535 to ATmega16
//-------------------------------------------------------------------------------------
// Include files  
#include <stdio.h>   
#include <string.h> 
#include <stdlib.h>
#include <delay.h> 
#include <mega16.h> 

#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h" 
//-------------------------------------------------------------------------------------
// USART Receiver buffer
char rx_buffer[RX_BUFFER_SIZE];
unsigned char rx_wr_index,rx_rd_index,rx_counter;
bit rx_buffer_overflow;  // This flag is set on USART Receiver buffer overflow
//-------------------------------------------------------------------------------------
// USART Transmitter buffer
char tx_buffer[TX_BUFFER_SIZE];
unsigned char tx_wr_index,tx_rd_index,tx_counter;
//-------------------------------------------------------------------------------------
void InitUSART(void)	// USART initialization, USART Mode: Asynchronous	
{
	UCSRA = 0x00;
	UCSRB = 0xD8;      	// Communication Parameters: 8 Data, 1 Stop, No Parity
	UCSRC = 0x06;      	// 8bit data communication
	UBRRH = 0x00;      	// USART Receiver: On;  USART Transmitter: On
	UBRRL = baudrate;  	// USART Baud rate: 115200
}
//-------------------------------------------------------------------------------------
// USART Receiver interrupt service routine
#pragma savereg-
interrupt [USART_RXC] void uart_rx_isr(void)
{
	char status,data;
	#asm
    	push r26
    	push r27
    	push r30
    	push r31
    	in   r26,sreg
    	push r26
	#endasm
	status=UCSRA;
	data=UDR;
	if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
   	{
   		rx_buffer[rx_wr_index]=data;
   		if (++rx_wr_index == RX_BUFFER_SIZE) rx_wr_index=0;
   		if (++rx_counter == RX_BUFFER_SIZE)
      	{
      		rx_counter=0;
      		rx_buffer_overflow=1;
      	};
   	};
	#asm
    	pop  r26
    	out  sreg,r26
    	pop  r31
    	pop  r30
    	pop  r27
    	pop  r26
	#endasm
}
#pragma savereg+
//-------------------------------------------------------------------------------------
#ifndef _DEBUG_TERMINAL_IO_
// Get a character from the USART Receiver buffer
#define _ALTERNATE_GETCHAR_
#pragma used+
char getchar(void)
{
	char data;
	while (rx_counter==0);
	data=rx_buffer[rx_rd_index];
	if (++rx_rd_index == RX_BUFFER_SIZE) rx_rd_index = 0;
	#asm("cli")
	--rx_counter;
	#asm("sei")
	return data;
}
#pragma used-
#endif
//-------------------------------------------------------------------------------------
// USART Transmitter interrupt service routine
#pragma savereg-
interrupt [USART_TXC] void uart_tx_isr(void)
{
	#asm
    	push r26
    	push r27
    	push r30
    	push r31
    	in   r26,sreg
    	push r26
	#endasm
	if (tx_counter)
   	{
   		--tx_counter;
     		UDR=tx_buffer[tx_rd_index];
     		if (++tx_rd_index == TX_BUFFER_SIZE) tx_rd_index = 0;
 	};
	#asm
 	pop  r26
 	out  sreg,r26
 	pop  r31
 	pop  r30
 	pop  r27
 	pop  r26
	#endasm
}
#pragma savereg+
//-------------------------------------------------------------------------------------
#ifndef _DEBUG_TERMINAL_IO_
// Write a character to the USART Transmitter buffer
#define _ALTERNATE_PUTCHAR_
#pragma used+
void putchar(char c)
{
	while (tx_counter == TX_BUFFER_SIZE);
	#asm("cli")
	if (tx_counter || ((UCSRA & DATA_REGISTER_EMPTY)==0))
   	{
   		tx_buffer[tx_wr_index] = c;
   		if (++tx_wr_index == TX_BUFFER_SIZE) tx_wr_index = 0;
   		++tx_counter;
   	}
	else UDR = c;
	#asm("sei")
}
#pragma used-
#endif
//------------------------------------------------------------------------------------- 

