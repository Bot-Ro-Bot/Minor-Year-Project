/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: command.c                                              */
/*                                                                       */
/*  Revision: V1.4     Date: 30.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Receives and Transmits data via Interrupt on USART ATmega16 */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein  27.12.2002 moved form rs232.c into separate file
// Updated by: Chr. Monstein  28.12.2002 debug features deleted to save flash memory
//                                      new command: Format %0...%3
// Updated by: Chr. Monstein  30.12.2002 test: single sweep with terminator only at the end
// Updated by: Hansueli Meyer 03.03.2003 new commands GSx and GAx 
// Updated by: Hansueli Meyer 17.03.2003 new commands FExyz and FRx
// Updated by: Hansueli Meyer 02.04.2003 new commands Lx sweeplenght
// Updated by: Hansueli Meyer 10.04.2003 new commands Ix integration time
// Updated by: Hansueli Meyer 14.04.2003 new commands FSx to set FPU
// Updated by: Hansueli Meyer 10.04.2003 new commands FMx, FLx and FHx tuner barriers
// Updated by: Hansueli Meyer 22.04.2003 new commands GD and GE enable and disable data transfer
// Updated by: Hansueli Meyer 07.05.2003 new commands PM1 and AM1 
// Updated by: Hansueli Meyer 14.05.2003 new commands S0 and S1 start and stop state machine
// Updated by: Hansueli Meyer 10.06.2003 new commands Q0-3 power splitter
// Updated by: Hansueli Meyer 22.07.2003 unused commands removed
// Updated by: Hansueli Meyer 16.10.2003 commands removed PM1 and AM1 
// Updated by: Hansueli Meyer 18.10.2003 new commands removed O0-8 Observation mode
// Updated by: Hansueli Meyer 25.10.2003 some changes in the commands S0 and S1   
// Updated by: Hansueli Meyer 02.12.2003 new command W send the initial and version code   
// Updated by: Hansueli Meyer 26.01.2004 Rx command sends result in switched off debug modus
// Updated by: Chr. Monstein  17.08.2010 Spannungsteiler angepasst fuer HAM-Version
// Updated by: Chr. Monstein  21.09.2010 Anpassungen an 10Bit HAM
// Updated by: Chr. Monstein  21.06.2011 Korrektur IF, debug-bit    
// Updated by: Chr. Monstien  02.03.2012 response to FE now two lines

//-------------------------------------------------------------------------------------
// Include files
#include <stdio.h>   
#include <string.h> 
#include <stdlib.h>
#include <delay.h>
#include <spi.h>
#include <mega16.h>   

#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h" 
#include "setfopa.h"  


//-------------------------------------------------------------------------------------

bit error = false;      // parameter error 
Byte format=4;          // default transmision format 8bit hex


extern bit softtrigger;         // import from callisto.c 
extern bit timertrigger;        // import from callisto.c 
extern bit transferdata;        // import from callisto.c 
extern bit externtrigger;       // import from callisto.c  
extern bit continuous;          // import from callisto.c  
extern bit stoptransfer;	// import from callisto.c   
extern bit adc_ready;           // import from adc.c   
extern bit adc_command;         // import from callisto.c  
extern bit eot_flag;            // import from callisto.c  
extern bit debug;               // import from callisto.c
extern Byte send_once;		// import from timer.c
extern Byte not_send;  

extern Byte FPUcodex;           // import from callisto.c 
extern bit reset_flag;		// import from callisto.c 	

Word sweeplength;               // frequency file length
Word low_band_max;   		  	
Word mid_band_max;  		   	
Word high_band_max;                      
Word pwm_value;   	

extern Word counter;            // import from callisto.c 
extern Word adc_value;          // import from adc.c 
extern Word measuringtime;      // import from callisto.c  
extern Word number_count; 	// import from callisto.c 
extern Word stepcount;          // import from command.c  
	
extern float uin;         	// import from callisto.c 
extern float rht;               // import from callisto.c 
extern float frequency; 		        // Actual frequency   
static volatile char tuner=0;   // Actual tuner address

Word prescaler_value_Syn;	// prescaler value is used in the timer.c init functions (11.0592MHz)		
Word prescaler_value_Asyn;	// prescaler value is used in the timer.c init functions (1MHz)

//-------------------------------------------------------------------------------------
void CommandInterpreter(char *cmd) 	// check incoming commands
{               
  	Byte u;            		// temporary command
  	Byte v;            		// temporary first parameter 
  	Byte w;            		// temporary second parameter
	Byte i;            		// common counter 
	Byte p;            		// common port register
	Word db1;                       // bytes used for the tuner
	Word db2;                       // bytes used for the tuner
	Word cb;                        // bytes used for the tuner
	Word bb;           		// bytes used for the tuner
	Word f_MHz;        		// temporary frequency  MHz
	Word fre_number;                // frequency number = EEPROM address 
	Word eeprom_address;            // used to generate the rigth EEPROM address			                  
	Word sweepcount;   		// used for single sweep   
	Word adc_tuner0;                // temporary saving of the tuner values
        //Word prescaler_value_Syn;	// prescaler value is used in the timer.c init functions (11.0592MHz)		
	//Word prescaler_value_Asyn;	// prescaler value is used in the timer.c init functions (1MHz)
	char temp[28]="";  		// string buffer  
	
	u=cmd[0];    			// save command character                               
	v=cmd[1]-48; 			// evaluate first command parameter (ASCII -> decimal)
	w=cmd[2]-48; 			// evaluate second command parameter (ASCII -> decimal)
	if (u=='A')  			// Read ADC
	{
		switch (v) 		// Evaluate parameter (ADC-channel)
		{
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			{  
				adc_value = Evaluate_ADC(v); // read the ADC_value 
				TransmitADC(adc_value);    
				break; 
			} 
			default: error = true; break; // illegal command
		}
	} 
	else 
	if (u=='C')  // ChargePump respective Clear Port
	{  
		switch (v) 	// Evaluate first parameter 
		{
			case 0:  break; // low phase noise, low speed
			case 1:  break; // high speed and much phase noise
			case 18: // Port B
			{     
				
				switch (w) 	// select bit in CBb
				{
					case 0: PORTB.0=0; break;
					case 1: PORTB.1=0; break;
					case 2: PORTB.2=0; break;
					case 3: PORTB.3=0; break;
					case 4: PORTB.4=0; break;
					case 5: PORTB.5=0; break;
					case 6: PORTB.6=0; break;
					case 7: PORTB.7=0; break;
					default: error = true; break; // illegal command
				}  
				break; 
			}
			case 19: 	// Port C
			{     
				switch (w) 	// select bit in CCb
				{
					case 0: PORTC.0=0; break;
					case 1: PORTC.1=0; break;
					case 2: PORTC.2=0; break;
					case 3: PORTC.3=0; break;
					case 4: PORTC.4=0; break;
					case 5: PORTC.5=0; break;
					case 6: PORTC.6=0; break;
					case 7: PORTC.7=0; break;
					default: error = true; break; // illegal command
				}
				break; 
			}
			case 20: 	// Port D
			{     
				switch (w) 	// select bit in CDb
				{
					case 0: PORTD.0=0; break;
					case 1: PORTD.1=0; break;
					case 2: PORTD.2=0; break;
					case 3: PORTD.3=0; break;
					case 4: PORTD.4=0; break;
					case 5: PORTD.5=0; break;
					case 6: PORTD.6=0; break;
					case 7: PORTD.7=0; break;
					default: error = true; break; // illegal command
				}
				break; 
			}
			default: error = true; break; // illegal command
		}
	} 
	else
	if (u=='D')  // Evaluate Debugmode
	{
		switch (v) 	// Evaluate parameter
		{
			case 0:  debug=false; break; // additional informations off
			case 1:  debug=true;  break; // additional informations on
			default: error=true;  break; // illegal command
		}
		if (debug)
			printf("$CRX:Debugmode on\r"); // Test message
	} 
	else 
	if (u=='f')  // fsx send focus code to set the FOPA
	{    
		switch (v) 	// Evaluate parameter
		{
			case 67: // fsx
			{
				sscanf(cmd,"fs%u",&FPUcodex); //get the sweeplength and send it to the internal EEPROM
				SetFPU((Byte)FPUcodex);				
				break;
			}                     
			default: error = true;  break; 	// illegal command
		}
		if (debug)
			printf("$CRX:FOPAcodex=%u\r",FPUcodex); // Test message
	} 
	else
	if (u=='F')  	// Evaluate frequencystring, set tuner and read and write to external EEPROM
	{   
		switch (v) 		// Evaluate parameter E or R which means writing or reading to EEPROM
		{
			case 0: // Tuner #0
			{
			  	i = 2; 		// ignore command-prefix and tuner address byte
				tuner = 0; 	// first parameter is tuner address
				do     
				{
					temp[i-2]=cmd[i]; // copy 2nd parameter to temporary string
					i++;
				} while (cmd[i]);
				frequency = atof(temp); // make float 
				SetTuner(frequency);  // tuner-address, frequency[MHz]    
				if (softtrigger)
				{
					adc_value = Evaluate_ADC(tuner); // read the ADC_value 
					TransmitADC(adc_value);    
				}
				break;
			}
			case 21: // EEPROM write FExxx,yyy.yyy,mmm (address[fre_number),frequency,modus)
			{	     
				sscanf(cmd,"FE%u,%03u,%03u,%03u,%03u",&fre_number,&db1,&db2,&cb,&bb); //read address
				sprintf(temp,"FE%u%u%u%u%u",fre_number,db1,db2,cb,bb);   
		  	        eeprom_address=(fre_number-1)*8;  //8 byte sent to EEPROM -> EEPROM address 8 times higher first frequency Nr.1
			        eeprom_write_string(eeprom_address,db1,db2,cb,bb);   // write at address x 
				if (debug)
    					printf("$CRX:%s\r",temp); // send frequency to host to check 
				break;
			}
			case 34: // EEPROM read FRxxx (address (number of frequency [fre_number]))
			{
				i = 2; 	// ignore command-prefix and tuner address byte
				do     
				{
			     		temp[i-2]=cmd[i]; // copy 2nd parameter to temporary string
					i++;
				} while (cmd[i]);	
			 	fre_number=atoi(temp); // make integer
			  	eeprom_address=(fre_number-1)*8; //generate the right EEPROM address
			        eeprom_read_float(eeprom_address,&db1,&db2,&cb,&bb); // read frequency at eeprom_address x  
				sprintf(temp,"EEPROM=%03u,%03u,%03u,%03u",(Byte)db1,(Byte)db2,(Byte)cb,(Byte)bb); // MHz 
				if (debug) 
				{
    					//frequency = ((float)(db1*256+db2)*0.0625)-37.75;
    					frequency = ((float)(db1*256+db2)*0.0625)-if_init; // 02.03.2012/cm
    					f_MHz = (Word)frequency;
					printf("$CRX:Frequency=%u.%uMHz\r",f_MHz,(Word)((frequency-f_MHz)*1000+0.5));
					printf("$CRX:%s\r",temp);
    				}
				break;	
			}  
			case 35: // FSxy set FOPA code  
			{     
				sscanf(cmd,"FS%02u",&(Byte)FPUcodex);// read modus (FOPAcode) to set FOPA  
				if (debug)
		  		{
					printf("$CRX:FPUcodex=%u\r",FPUcodex); // send FOPA code to host		
				} 		
				break; 
			}     
			case 28: // FL low_band_max of tuner   test band switching
			{
				sscanf(cmd,"FL%u",&low_band_max); //read address, frequency and modus 
				sprintf(temp,"%u",low_band_max);   
				EEPROM_write(address_lowband, temp); // write
				break;				
			} 	
			case 29: // FM mid_band_max of tuner
			{
				sscanf(cmd,"FM%u",&mid_band_max); //read address, frequency and modus 
				sprintf(temp,"%u",mid_band_max);   
				EEPROM_write(address_midband, temp); // write
				break;				
			} 	
			case 24: // FH high_band_max of tuner
			{
				sscanf(cmd,"FH%u",&high_band_max); //read address, frequency and modus 
				sprintf(temp,"%u",high_band_max);   
				EEPROM_write(address_highband, temp); // write
				break;				
			} 
			
			default: error = true;  break; 		// illegal command
		}	     
	}
	else
	if (u=='G')  // Set the counter and enable or disable the main interrupt
	{
		transferdata = false;
		switch (v) 	// Evaluate parameter
		{
			case 20: // D=GD disable the datatransfer between host and mainboard
			{
				transferdata = true;
				eot_flag = true;				
				break;
			}       
			case 21:// E=GE enable the datatransfer between host and mainboard
			{
				transferdata = false;				
				break;
			}         
			case 35:// S=GS set the interrupt repeat rate 1Hz, 50Hz, 200Hz, 400Hz
			{		  
  				sscanf(cmd,"GS%u",&prescaler_value_Syn); //read address, frequency and modus 
 				break; 
			}           
			case 17:   // A=GA set the interrupt repeat rate 20Hz, 200Hz, 400Hz
			{		  
  				sscanf(cmd,"GA%u",&prescaler_value_Asyn); //read address, frequency and modus 
				break;  
			}                   
			default: error = true;  break; 		// illegal command
		}
	} 
	else  			
	if (u=='L')  // Evaluate sweep Length
	{    
		sscanf(cmd,"L%u",&sweeplength); //get the sweeplength and send it to the internal EEPROM 
		if (debug)
			printf("$CRX:Sweeplength=%u\r",sweeplength); // Test message
	} 
	else  
	if (u=='M')  // Evaluate measuring delay
	{              
		i=1; // ignore command-prefix
		do     
		{
			temp[i-1] = cmd[i]; // copy 1st parameter to temporary string
			i++;
		}while (cmd[i]);
		measuringtime = atoi(temp); // make Word
		if (debug)
			printf("$CRX:MeasuringDelay=%s\r",temp); // Test message
	} 
	else
	if (u=='O')  // Set PWM-value for gain-control
	{              
	  
		sscanf(cmd,"O%u",&pwm_value); //
		OCR2 = pwm_value;  // timer 2, PORT D bit 7
	        if (debug)
	                printf("$CRX:OCR2=%u\r",pwm_value); // send FOPA code to host  				
	} 	
        else
	if (u=='P')  // Evaluate Processmode   
	{     
		switch (v) // Evaluate parameter
		{
			case 0: // Stop 
			{             
				continuous = false;
				if (debug)
					printf("$CRX:P0=Stop recording\r"); // Test message
				break; 
			}
			case 1: // continous recording
			{
				continuous = true;
				if (debug)
					printf("$CRX:P1=Start recording\r"); // Test message
				break;
			}
			case 2: // Single sweep
			{                         			
				if (debug) 
					printf("$CRX:P2=Start single sweep\r"); // Test message
				sweepcount = 0;
				do
				{     
					frequency = frequency + synthesizer_resolution; // test frequency [TBD]
					SetTuner(frequency);  // tuner-address, frequency[MHz]   
					if (softtrigger)
					{
						adc_tuner0 = Evaluate_ADC(tuner); // read the ADC_value 
						delay_ms(measuringtime); // wait 
						TransmitADC(adc_tuner0); 
					}                 
					sweepcount++;
				} while (sweepcount < sweeplength);
				if (format==4)  
					printf(carriage_return); // Send carriage return  
				if (debug)
					printf("$CRX:P2=Stop single sweep\r"); // Test message
				break;
			}
			default:  error = true; break; // illegal command
		}
	}   
	else
	if (u=='+')  // P3 increment in 62.5kHz steps
	{                 
		if (debug)
			printf("$CRX:Single step +62.5kHz\r"); // Test message
		frequency = frequency + synthesizer_resolution; 
		SetTuner(frequency);  		// old tuner-address, frequency[MHz]    
		if (softtrigger)
		{
			adc_value = Evaluate_ADC(tuner); // read the ADC_value 
			TransmitADC(adc_value);    
		}                 
		sweepcount++;
		if (sweepcount > sweeplength) 
			sweepcount = 0;
	}
	else	
	if (u=='-')  // P4 decrement in 62.5kHz steps
	{                 
		if (debug)
			printf("$CRX:Single step -62.5kHz\r"); // Test message
		frequency = frequency - synthesizer_resolution; 
		SetTuner(frequency);  		// old tuner-address, frequency[MHz]    
		if (softtrigger)
		{
			adc_value = Evaluate_ADC(tuner); // read the ADC_value 
			TransmitADC(adc_value);    		
		}                 
		sweepcount--;
		if (sweepcount<1) 
			sweepcount = sweeplength;
	}	
	else
	if (u=='R')  // Read Port(s)
	{  
		switch (v) // Evaluate parameter A...D
		{
			case 17: p=PORTA;   break; // A
			case 18: p=PINB;   break; // B
			case 19: p=PORTC;   break; // C
			case 20: p=PIND;    break; // D    
			//printf("PORTB.%u=%u\r",0,PINB.0);

			default: error = true; break; // illegal command
		}
		sprintf(temp,"PORT%c=%u",cmd[1],p);
		printf("$CRX:%s\r",temp); // send result to host
	} 
	else 
	if (u=='S')  // Set Port
	{  
		switch (v) // Evaluate first parameter 
		{
			case 0: // S0 stop state machine
			{  	
				StopTimer(); 	// disable the interrupt service routine (state machine)
				printf("$CRX:Stopped\r"); // state machine started
				chip_select = 1;      // chip select high   
			        WDTCR = 0x1C;         // disable the watchdog timer
			        WDTCR = 0x17;
				if (debug)   
				{
					printf("$CRX:Sweeplength%u\r",sweeplength); // send number of choosen frequencies to host to check   				
					printf("$CRX:Stop state machine\r");   
				}	
				break;				
			} 
			case 1:  // start state machine
			{			
				chip_select = 0;     // chip select low used for the external EEPROM
				spi(0x03);	// Command: read EEPROM
				spi(0x00);	// Address high byte
    				spi(0x00);	// Address low byte   
     		     		counter      = 0;      // Init counter variable 
     		     		stepcount    = 0;      // Init the intgration counter
     		    		number_count = 0;      // reset the number of counts         		 	 
     		    		set_once = true;
     		    		transferdata = true; // reset and enable the datatransfer between host and mainboard\
     		    		stoptransfer = false;    // disable the datatransfer   (state machine)
     		     	 	send_once    = true;         
     		    		not_send     = false;  
     		    		eot_flag     = false; 		// don't send the eot character at start
     		     		WDTCR |= (1<<WDE);   	// Write logical one to WDE watchdog enable flag
     				if (debug)
     			 		printf("$CRX:Start state machine\r");
     				printf("$CRX:Started\r"); // state machine started 
     				printf("%u",2);   // start of transmission  
     				StartTimer();  // enable the interrupt service routine			
     				break;
			}  
			//case 17: // Port A forbidden
			case 18: // Port B
			{     
				switch (w) // select bit in SBb
				{
					case 0: PORTB.0=1; break;
					case 1: PORTB.1=1; break;
					case 2: PORTB.2=1; break;
					case 3: PORTB.3=1; break;
					case 4: PORTB.4=1; break;
					case 5: PORTB.5=1; break;
					case 6: PORTB.6=1; break;
					case 7: PORTB.7=1; break;
					default: error=true; break; // illegal command
				}
				break; 
			}
			case 19: // Port C
			{     
				switch (w) // select bit in SCb
				{
					case 0: PORTC.0=1; break;
					case 1: PORTC.1=1; break;
					case 2: PORTC.2=1; break;
					case 3: PORTC.3=1; break;
					case 4: PORTC.4=1; break;
					case 5: PORTC.5=1; break;
					case 6: PORTC.6=1; break;
					case 7: PORTC.7=1; break;
					default: error=true; break; // illegal command
				}
				break; 
			}
			case 20: // Port D
			{     
				switch (w) // select bit in SDb
				{
					case 0: PORTD.0=1; break;
					case 1: PORTD.1=1; break;
					case 2: PORTD.2=1; break;
					case 3: PORTD.3=1; break;
					case 4: PORTD.4=1; break;
					case 5: PORTD.5=1; break;
					case 6: PORTD.6=1; break;
					case 7: PORTD.7=1; break;
					default: error=true; break; // illegal command
				}
				break; 
			} 
			default: error = true; break; // illegal command
		}
	} 
	else 
	if (u=='T')  // Trigger mode
	{          
		softtrigger   = false;
		timertrigger  = false;
		externtrigger = false;
		switch (v) // Evaluate parameter 0..2
		{
			case 0: // T0=trigger via software
			{
				softtrigger = true; 
				break;     
			}
			case 1: // T1=trigger via ATmega16 crystal 11.0592MHz
			{
				InitTimerSynClock(prescaler_value_Syn);  //internal syn. clock 11.0592MHz
				if (debug)
    					printf("$CRX:internal clock\r");	
				timertrigger = true; 
				break; 
			}
			case 2: // T2=trigger via external clock
			{				
				InitTimerAsynClock(prescaler_value_Asyn); //external asyn. clock 1MHz Timer/counter1 is used
				if (debug)
    					printf("$CRX:external clock\r");
				externtrigger = true; 
				break;    
			}
			default: error = true; break; // illegal command
		} 
	} 
	else   
	if (u=='U')  // Read system voltages
	{                 
 		adc_value = Evaluate_ADC(v);
 		uin = (float)adc_value*adc_reference/adc_resolution; // get voltage  
		switch (v) // Evaluate parameter
		{
			case 2: // receiver gain control voltage 
			{
				rht = 2.0*uin/adc_scaling;
				printf("$CRX:AGC gain = %u.%02uV\r",(int)(rht),(int)(100.0*(rht-(int)(rht)) ));
				break; 

			}
			case 3: // GND
			{
				break; 
			}         
			case 4: // GND
			{                                                 
                               	rht = uin/adc_scaling;
				printf("$CRX:Emitter BF199 = %u.%02uV\r",(int)(rht),(int)(100.0*(rht-(int)(rht)) ));
				break; 
			}
			case 5: // GND
			{                                              
				break; 	
			}  	
			case 6: // � input voltage (+12V)
			{                                              
				rht = uin/(adc_scaling)*6.6;
				printf("$CRX:Analog Input = %u.%02u%V\r",(int)(rht),(int)(100.0*(rht-(int)(rht)) ));
				break;  	
			}	
			case 7: // GND
			{                                              
				break; 
			}
			default: error = true;  break; // illegal command
		}
	} 
	else
	if (u=='%')  // Transmision format (for tests only)
	{          
		switch (v) // Evaluate parameter 0..2
		{
			case 0: format=0; break; 		// decimal 10bit
			case 1: format=1; break; 		// decimal 8bit
			case 2: format=2; break; 		// Millivolt
			case 3: format=3; break; 		// HEX TransmitString()
			case 4: format=4; break; 		// HEX SendString()
			case 5: format=5; break; 		// frequency+decimal Millivolt
			default: error = true;  break; 	// illegal command
		} 
		if (debug)
			printf("$CRX:TransmissionFormat=%u\r",format); // Test message
	} 
	else 
	if (u=='?')  // Read system infos
	{                 			
  		printf("$CRX:%s\r",version);  // Start message (version)  
  				 	
		if (debug)
			printf("$CRX:Debug=On\r");
		else
			printf("$CRX:Debug=Off\r");
	
		if (softtrigger)
			printf("$CRX:Trigger=Soft\r");
		else
		if (timertrigger)
			printf("$CRX:Trigger=Intern\r");
		else
		if (externtrigger)
			printf("$CRX:Trigger=Extern\r");
		else
			printf("$CRX:Trigger=No\r"); 
		
		printf("$CRX:FPUcodex=%u\r",FPUcodex);    
		printf("$CRX:GS =%u\r",prescaler_value_Syn);  
		printf("$CRX:GA =%u\r",prescaler_value_Asyn);  
		
		printf("$CRX:Delay=%umsec\r",measuringtime); // soft-delay
													
		f_MHz = (Word)frequency;
		printf("$CRX:Frequency=%u.%uMHz\r",f_MHz,(Word)((frequency-f_MHz)*1000+0.5)); // MHz
		
		printf("$CRX:Sweeplength=%u\r",sweeplength); // pixel    
		
		low_band_max = EEPROM_read(115); // TL low_band_max value
		printf("$CRX:low_band_max=%uMHz\r",low_band_max); // pixel
		
		mid_band_max = EEPROM_read(120); // TM mid_band_max value
		printf("$CRX:mid_band_max=%uMHz\r",mid_band_max); // pixel
		
		high_band_max = EEPROM_read(125); // TH high_band_max value
		printf("$CRX:high_band_max=%uMHz\r",high_band_max); // pixel
		
		//printf("$CRX:Idle=%ux\r",idlecount);
		printf("$CRX:Idle=0\r");
	} 
	else  
	if (u=='\0')  // ENTER pressed by the host/user
	{  
		// nothing to do
	}
	else
		error = true; 
	
	// check error state 	
	if (error) 
	{
		printf("$CRX:illegal command!\r"); // unknown command, no further action
		error = false; // Reset error flag
	}
}
//-------------------------------------------------------------------------------------

	
	           