/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: digital_io.c                                           */
/*                                                                       */
/*  Revision: V1.0     Date: 30.11.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Initializes, Sets and Resets bits on Digital Input/Output   */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 26.11.2002  
// Updated by: Chr. Monstein 30.11.2002
// Updated by: Chr. Monstein 30.11.2002
// Updated by: Meyer Hasnueli 08.04.2003 SPI outputs set
//-------------------------------------------------------------------------------------

#include <mega16.h>
#include <stdio.h> 
#include <stdlib.h>
   
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"

//-------------------------------------------------------------------------------------
void InitDigital_IO(void)
{
	// Data Direction Register Port C
	DDRC=0xFF; 				// Port C all bits output for debugging via STK500
 	PORTC=0xFF; 				// set all LEDs dark...	
 	
 	PORTD=0x3F; 				// Port D initialization
	DDRD=0xF3;                              // Port PD7 PWM output
      
 	// Data Direction Register Port B
	// SPI initialization
	// SPI Type: Master
	// SPI Clock Rate: 2764.800 kHz relates to a MHz crystal
	// SPI Clock Phase: Cycle Half
	// SPI Data Order: MSB First	
 	DDRB=0xBC; 	//SPI Bus I/O, SCK=out, MISO=IN, MOSI=out, CS=out
 	SPCR=0x50; 
	PORTB=0xB7;   
        
	
	// Timer/Counter 2 initialization
	// Clock source: System Clock
	// Clock value: 11059.200 kHz
	// Mode: Phase correct PWM top=FFh
	// OC2 output: Non-Inverted PWM
	ASSR=0x00;
	TCCR2=0x61;
	TCNT2=0x00;
	OCR2=0x00;	
}
//-------------------------------------------------------------------------------------
