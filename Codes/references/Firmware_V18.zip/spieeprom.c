/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: spieeprom.c                                            */
/*                                                                       */
/*  Revision: V1.0     Date: 27.01.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: external EEPROM read and write functions via SPI Bus        */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 27.01.2003  
// Updated by: Hansueli Meyer 04.02.2003  reading and writing 8byte
// Updated by: Hansueli Meyer 30.03.2003  Timer and EEPROM in the same program
// Updated by: Hansueli Meyer 02.04.2003  new function EEPROM reading sequential 
// Updated by: Hansueli Meyer 15.04.2003  modus 0-255 stored in the EEPROM  
// Updated by: Hansueli Meyer 14.10.2003  acknowledge for software handshaking 
//-------------------------------------------------------------------------------------      

//include files
#include <delay.h>       
#include <spi.h>     
#include <stdio.h>
#include <mega16.h>
#include <stdlib.h>
 
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"   

extern Word sweeplength;  // import from callisto.c
extern Word number_count; // import from callisto.c

//------------------------------------------------------------------------------------

void eeprom_read_float(Word address,Byte *db1,Byte *db2,Byte *cb,Byte *bb) //Read 8 byte from external EEPROM
{
	chip_select=0;          // chip select low activate EEPROM
	spi(0x03);			// Command read EEPROM
	spi(address / 256);	// Address high byte
	spi(address % 256);	// Address low byte
	
	*db1=spi(0); 
	*db2=spi(0);
	*cb=spi(0);
	*bb=spi(0);
   		  	
	chip_select=1;          // chip select high stop reading mode    
}    

//-------------------------------------------------------------------------------------
void eeprom_write_string(Word address, Byte db1,Byte db2, Byte cb,Byte bb) // Write 8 byte to external EEPROM
{								   	  
	chip_select=0; // chip select low
	spi(0x06);     // write enable byte
	chip_select=1; // chip select high
	chip_select=0; // chip select low
        spi(0x02);     // command write EEPROM   
	spi(address / 256); // Address high byte
	spi(address % 256); // Address low byte
	spi(db1);
	spi(db2);
	spi(cb);
	spi(bb);
	spi(0x00);
	spi(0x00);
	spi(0x00);
	spi(0x00);	
	
	chip_select=1; // chip select high stop writing mode
	delay_ms(6); // 6ms delay to finishing the write cycle
	printf("]"); // acknowledge for software handshaking between mainboard and host	
}
//-------------------------------------------------------------------------------------            







