/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: digital_io.h                                           */
/*                                                                       */
/*  Revision: V1.0     Date: 30.11.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Prototype definitions for source c-files                    */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 26.11.2002 
// Updated by: Chr. Monstein 30.11.2002

//-------------------------------------------------------------------------------------

#ifndef digital_io.h
#define digital_io.h

void InitDigital_IO( void);   // init PORTA, PORTB, PORTC and PORTD

#endif

//-------------------------------------------------------------------------------------

