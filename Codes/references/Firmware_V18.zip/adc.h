/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: adc.h                                                  */
/*                                                                       */
/*  Revision: V1.0     Date: 30.11.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Prototype definitions for source c-files                    */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 30.11.2002 
// Updated by: Chr. Monstein 30.11.2002   
// Updated by: Hansueli Meyer 12.05.2003 new function Read_ADC
// Updated by: Chr. Monstein  21.09.2010 Anpassungen an 10Bit HAM

//-------------------------------------------------------------------------------------

#ifndef adc.h
#define adc.h
                       
#define ADC_VREF_TYPE 0x00   
#define ADIF 4

interrupt [ADC_INT] void adc_isr(void);   // interrupt service routine

Word Evaluate_ADC(Byte trigger_number);  // read ADC and evaluate the values
void InitADC(void);   // init the Analog Digital Converter
void TriggerADC(Byte channel); // Trigger ADC0 or ADC1 
void TransmitADC(Word value);	  // send the measured result to host  

#endif

//-------------------------------------------------------------------------------------
