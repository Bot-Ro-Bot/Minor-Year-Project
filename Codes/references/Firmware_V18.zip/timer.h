/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: timer.h                                                */
/*                                                                       */
/*  Revision: V1.0     Date: 10.03.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: Prototype definitions for source c-files                    */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 10.03.2003
// Updated by: Hansueli meyer 06.06.2003 new function watchdog

/*-----------------------------------------------------------------------*/

#ifndef timer.h
#define timer.h   

#define WDE 3     // Watchdog enable bit

#define enable_interrupt 0x10 				// enable Timer/counter1 interrupt
#define disable_interrupt 0x00				// disable Timer/counter1 interrupt
//------------------------------------------------------------------------------------ 
void Init_Watchdog(void); 					// Watchdog Timer	
void InitTimerSynClock(Word prescaler_value_Syn); 	// counter/timer1 compare match interrupt (internal 11.0592MHz system clock)
void InitTimerAsynClock(Word prescaler_value_Asy);	// counter/timer1 compare match interrupt (external clock e.g. 1MHz atomic clock)
void StartTimer(void); 						// Start counter/timer1 isr
void StopTimer(void); 						// Stop counter/timer1 isr
interrupt [TIM1_COMPA] void timer1_compa_isr(void);   //compare match interrupt

#endif

//-------------------------------------------------------------------------------------