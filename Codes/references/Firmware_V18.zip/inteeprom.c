/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: inteeprom.c                                            */
/*                                                                       */
/*  Revision: V1.0     Date: 22.04.2003    Autor: Hansueli Meyer         */
/*                                                                       */
/*  Purpose: internal EEPROM read and write cycle			       */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Hansueli Meyer 22.04.2003  
// Updated by: 
//-------------------------------------------------------------------------------------      

//include files
#include <delay.h>       
#include <spi.h>     
#include <stdio.h>
#include <mega16.h>
#include <stdlib.h> 
#include <math.h> 
 
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"

//-------------------------------------------------------------------------------------      
void EEPROM_write(Word uiAddress, char *datastring) // write 5 byte to the internal EEPROM
{
	Byte i;    
	for (i = 0; i <= 4; i++)
	{ 
		
		while(EECR & (1<<EEWE)) // Wait for completion of previous write
			;
		EEAR = uiAddress+i;     // Set up address and data registers
		EEDR = datastring[i];
		EECR |= (1<<EEMWE);    	// Write logical one to EEMWE
		EECR |= (1<<EEWE);      // Start eeprom write by setting EEWE 
	}            
}
//------------------------------------------------------------------------------------- 
float EEPROM_read(Word uiAddress)   // read 5 byte from the internal EEPROM
{
	Byte x;
	char datastring[6];
	for(x = 0; x <= 4; x++)     
		{

			while(EECR & (1<<EEWE)) // Wait for completion of previous write
				;
			EEAR = uiAddress+x; // Set up address register 
			EECR |= (1<<EERE);  // Start eeprom read by writing EERE 
			datastring[x] = EEDR; // Return data from data register 			 
		}                         	
	datastring[5]='\0';            
	return atof(datastring);       
}
//------------------------------------------------------------------------------------- 




                                    