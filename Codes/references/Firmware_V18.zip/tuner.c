/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: tuner.c                                                */
/*                                                                       */
/*  Revision: V1.2     Date: 10.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Transmits i2c-signals to the Philips TV-tuner CD1316        */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 16.04.2001
// Updated by: Chr. Monstein 30.11.2002 Adaption to Callisto
// Updated by: Chr. Monstein 10.12.2002 synthesizer_resolution KHz->MHz
// Updated by: Chr. Monstein 21.09.2010 Anpassungen an 10Bit HAM

//---------------------------------------------------------------------------  
// Include files
#include <mega16.h>
#include <stdio.h> 
#include <stdlib.h>
  
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"

//---------------------------------------------------------------------------
// Global variables import/export
extern Word low_band_max;   			
extern Word mid_band_max;  			
extern Word high_band_max;  

//---------------------------------------------------------------------------
void I2C_Init(void)
{    
   SCL = 1;
   SDA = 1;                  
} 
//---------------------------------------------------------------------------
void I2C_SDA(Byte arg)
{                     
   if (arg)
     SDA = 1;
   else
     SDA = 0;
}
//---------------------------------------------------------------------------
void I2C_SCL(Byte arg)
{                     
   if (arg)
     SCL = 1;
   else
     SCL = 0;
}
//---------------------------------------------------------------------------
void I2C_Start(void) 
{                     
   I2C_SDA(0);
   I2C_SCL(0);
   I2C_SDA(1);
   I2C_SCL(1);
   I2C_SDA(0);
   I2C_SCL(0);
}
//---------------------------------------------------------------------------
void I2C_Stop(void)
{          
   I2C_SDA(0);           
   I2C_SCL(0);
   I2C_SCL(1);
   I2C_SDA(1);           
}
//---------------------------------------------------------------------------
void I2C_Wrbyte(Byte arg) // write 1 byte to device, serial output, MSB first
{                              
    Byte x;
    Byte power = 128;
    for (x=1; x<=8; x++)
    {
       I2C_SDA(0); 
       I2C_SCL(0);
       if ((arg & power) == power)
       {
          I2C_SDA(1);
          I2C_SCL(1);
          I2C_SCL(0);
          I2C_SDA(0);
       }
       else 
       {
          I2C_SDA(0);
          I2C_SCL(1);
          I2C_SCL(0);
       }   
       power = power / 2;
    }   
    // get acknowledge       
    I2C_SCL(1);
    I2C_SCL(0);
}
//---------------------------------------------------------------------------
void SetTuner(float actualfrequency) // set tuner to new frequency
{
    Word divider;
    Byte db1, db2;  			// divider byte 1 and 2
    Byte adb, cb, bb; 			// address byte, control byte 1 and 2

    adb = 128 + 64 + 0; 		// evaluate tuner adress byte 110000xxB
    
    // estimate oscillator divider bytes
    divider=(unsigned int)( (actualfrequency+if_init)/synthesizer_resolution); // MHz->KHz->channel
    db1 = (Byte) (divider / 256); 	// evaluate first data byte
    db2 = (Byte) (divider % 256); 	// evaluate second data byte

    cb = 128 + 64 + 4 + 2; 		// tuner control byte 62.5khz
 
    // bb setting according to oscillator frequency (band select)
    if (actualfrequency <= low_band_max) 	// low band 51-171MHz = 00000001
        bb = 1; 
    else
    {
        if (actualfrequency <= mid_band_max) // mid band 178-450MHz = 00000010
            bb = 2; 
        else 				// high band 458-858MHz = 00000100
            bb = 4; 
    }            
                  
    // Output sequence to device via digital-I/O-Port, send start bit first
    I2C_Start();
    
    I2C_Wrbyte(adb); // Send address byte
    I2C_Wrbyte(db1); // Send divider byte 1
    I2C_Wrbyte(db2); // Send divider byte 2
    I2C_Wrbyte(cb);  // Send control byte
    I2C_Wrbyte(bb);  // Send band-switch byte
    
    // Send stopp bit
    I2C_Stop();
}
//---------------------------------------------------------------------------












