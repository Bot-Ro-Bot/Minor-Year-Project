/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: callisto.h                                             */
/*                                                                       */
/*  Revision: V1.0     Date: 30.11.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Prototype definitions for source c-files                    */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein 26.11.2002 
// Updated by: Chr. Monstein 30.11.2002

//-------------------------------------------------------------------------------------

#ifndef callisto.h
#define callisto.h
                       
typedef unsigned char Byte;
typedef unsigned int Word;

#define true 1    
#define false 0  

//void Idle(void); 				// all other permanent activities (except serial input)

#endif
//-------------------------------------------------------------------------------------

