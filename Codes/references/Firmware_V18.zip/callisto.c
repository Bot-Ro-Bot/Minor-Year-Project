/*-----------------------------------------------------------------------*/
/*  (C) Copyright Institute of Astronomy ETHZ 8092 Zuerich Switzerland   */
/*-----------------------------------------------------------------------*/
/*  Programmname: callisto.c                                             */
/*                                                                       */
/*  Revision: V1.0     Date: 30.12.2002    Autor: Chr. Monstein          */
/*                                                                       */
/*  Purpose: Mainprogram of frequency agile Radiospectrometer CALLISTO   */
/*                                                                       */
/*  Compiler: CodeVisionAVR VERSION 1.23                                 */
/*-----------------------------------------------------------------------*/

// Created by: Chr. Monstein  26.11.2002 Begin
// Updated by: Chr. Monstein  02.12.2002 new flags introduced
// Updated by: Chr. Monstein  10.12.2002 new version
// Updated by: Chr. Monstein  27.12.2002 heater flags introduced
// Updated by: Chr. Monstein  28.12.2002 Test-table with tuner-frequencies introduced
// Updated by: Chr. Monstein  30.12.2002 adc-transmission without terminator
// Updated by: Meyer Hansueli 01.04.2003 Changed from At90S8535 to ATmega16 (11.0592MHz) 
// Updated by: Meyer Hansueli 12.05.2003 band barrier setting fot tuner0 and tuner1 introduced
// Updated by: Meyer Hansueli 01.07.2003 Watchdog introduced   
// Updated by: Meyer Hansueli 11.10.2003 observation mode in the mainloop introduced      
// Updated by: Chr. Monstein  17.08.2010 Spannungsteiler angepasst fuer HAM-Version
// Updated by: Chr. Monstein  21.09.2010 Anpassungen an 10Bit HAM
// Updated by: Chr. Monstein  21.06.2011 delete idlecount   
// Updated by: chr. Monstein  02.03.2012 new Quartz 25,43 MHz
//-------------------------------------------------------------------------------------
// Include files
#include <stdio.h>  
#include <string.h> 
#include <delay.h>
#include <spi.h>  
#include <mega16.h> 
#include <stdlib.h>
  
#include "callisto.h"   
#include "rs232.h"  
#include "command.h"
#include "digital_io.h" 
#include "tuner.h"     
#include "adc.h"
#include "timer.h" 
#include "inteeprom.h"  
#include "spieeprom.h"  
#include "setfopa.h"  


//-------------------------------------------------------------------------------------
// Global Variables (Public)
char initial[] = "e-Callisto ETH Zurich"; // < 20 Bytes! 
//char version[] = "V1.6, 2010-08-17";              
//char version[] = "V1.7, 2011-06-21";              
char version[] = "V1.8 / 2012-03-02";              

bit debug;          	// shall we send acknowledge back to the host? 
bit adc_command=false;  // transmit adc value or not
bit softtrigger;    	// software triggered ADC?   
bit timertrigger;   	// timer pacer triggered ADC?
bit externtrigger;  	// external triggered ADC?      
bit continuous;     	// steady recording?
bit transferdata;   	// transfer data from mainboard to host?   
bit stoptransfer;	  	// stop the transfer in the interrupt routine   
bit eot_flag;           // send eot character when transmission has finished
bit send_result;

extern bit rx_buffer_overflow; //from rs232.c file imported
extern Byte rx_counter; //from rs232.c file imported   
extern Word adc_value;	// import from adc.c                         
extern Word low_band_max; // import from command.c 	
extern Word mid_band_max;  // import from command.c 	
extern Word high_band_max; // import from command.c  

Byte set_once;           // don't send the first two results
Byte not_send;           // don't send the first two results
Byte send_once;          // import from timer.c    
Byte FPUcodex;           // import from callisto.c 
bit reset_flag;	         // used to test the watchdog   
Word result;             // state machine tuner value

Word counter;       	 // count the measured frequencies used in command.c (GH)
//Word idlecount;     	 // something to count
Word number_count; 	 // count the measured frequencies
Word stepcount;          // count the integration steps
Word measuringtime; 	 // delay between software triggered measurements


float uin;       		// used to read the system voltages, temperature and humidity
float rht;       		// used to read the system voltages, temperature and humidity 
float frequency; 		// Actual frequency  

eeprom float rx_init=(PopularRadio); // Power up with most popular receiving frequency
eeprom float if_init=(RX_IF); 	// Power up if-center-frequency    

//-------------------------------------------------------------------------------------
void main( void ) // Testprogram to take control of ATmega16-functions
{                        
	char runcomm [RX_BUFFER_SIZE+1] = ""; 	// space MUST be reserved!
	char data = '\0';      				// Buffer for one single incoming byte to work with
	char tmp[16]="";  				// string buffer  
	Byte cmdcount = 0;     				// counts the incoming bytes from RS232 port 
	debug         = false; 				// per default no acknowledge to the host
	softtrigger   = false; 				// per default no software triggered ADC   
	timertrigger  = false; 				// per default no pacer timer triggered ADC
	externtrigger = false; 				// per default no external triggered ADC 
 	stoptransfer  = false;                          // per default transfer data
	transferdata  = true;  		                // per default don't transfer data from mainboard to host 	 			
	continuous    = false; 				// per default no recording initially
	eot_flag      = false; 				// don't send the eot character      
	send_once     = true;                           // send the eot character once
	reset_flag    = true;				// watchdog on at start	
	set_once      = true;                           // send one result per step in the interrupt
	not_send      = false;                          // don't send the first two bytes of main process
	send_result=false;                              // no data sending at start
	measuringtime = 0;     			        // per default no delay, full speed during design phase, later -> 1msec	
	
	low_band_max=171; 			        // Init band barriers of tuner
	sprintf(tmp,"%u",low_band_max);   
	EEPROM_write(address_lowband, tmp);             // write  to internal EEPROM
 	mid_band_max=450;  			        // Init band barriers of tuner
  	sprintf(tmp,"%u",mid_band_max);   
	EEPROM_write(address_midband, tmp);             // write  to internal EEPROM
	high_band_max=863;                              // Init band barriers of tuner
	sprintf(tmp,"%u",high_band_max);   
	EEPROM_write(address_highband, tmp);            // write  to internal EEPROM
	
	InitDigital_IO(); 				// Set I/O-ports and bits     	   	
	InitUSART(); 					// Set the baudrate to 115,200 bps using a 11.0592MHz crystal
	InitADC(); 					// ADC initialization, Clock frequency: 57.656 kHz, Interrupts: On  
	I2C_Init();                                     // Prepare I2C-bus
	Init_Watchdog(); 				// Watchdog Timer Initialization	
	TriggerADC(1);                                  // triger ADC for the first time	
 	delay_ms(100); 					// not neccessary for <= 19'200Baud 	
 	TriggerADC(0);                                  // triger ADC for the first time

	#asm("sei()") 					// Enable interrupts => enable USART interrupts
                    
 	printf("$CRX:%s\r",initial);                    // Start message (title)
  	printf("$CRX:%s\r",version); 	                // Start message (version)  		 	
	
 	SetTuner(rx_init);  		                // Set tuner to the most popular radio transmitter
 
	while(1)  					// Do, as long as power is available...
	{           
		if (rx_counter>0) 			// if data in RX buffer
		{
			data = getchar() & 0x7F; 	// Store the received character
			if (data==carriage_return) 	// Transmission terminator available?
			{    
				runcomm[cmdcount]='\0'; // Terminate running command
				cmdcount=0; 			// Reset command byte counter
				CommandInterpreter(runcomm); 	// Interpretation of command string
				if (debug)
				{
					printf("$CRX:Command=<%s>\r",runcomm); // Message to host
				}
				runcomm[0]='\0'; 	 // Delete and terminate running command 
			}
			else
			{
				runcomm[cmdcount++]=data; // put next character into tar-command-string
				if (rx_buffer_overflow>0) //(cmdcount>UART_RX_BUFFER_SIZE) 
				{
					printf("$CRX:RX_buffer_overflow\r"); 
					cmdcount = 0; 	          // Reset string because it is too long 
					rx_buffer_overflow = 0;   // reset error
				  	runcomm[cmdcount] = '\0'; // Kill running command
				}
			}              
		} // end if (DataInReceiveBuffer())
		else
		{     
			// idle
		}
		if (send_result) 
		{
		    printf("%04X",result);      // 10bit
		    send_result = false;
		}  			
	} // end for( ; ; ) 
}
//-------------------------------------------------------------------------------------
